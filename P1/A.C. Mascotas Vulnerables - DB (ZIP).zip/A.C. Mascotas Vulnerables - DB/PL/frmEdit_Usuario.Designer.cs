﻿namespace A.C.Mascotas_Vulnerables___DB.PL
{
    partial class frmEdit_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEdit_Usuario));
            this.encabezado = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmdCerrar = new ns1.BunifuImageButton();
            this.lblTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtIngreso = new ns1.BunifuDatepicker();
            this.label16 = new System.Windows.Forms.Label();
            this.dtNacimiento = new ns1.BunifuDatepicker();
            this.cbCargo = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txttelefono = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.bunifuSeparator8 = new ns1.BunifuSeparator();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.bunifuSeparator11 = new ns1.BunifuSeparator();
            this.txtrfc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.bunifuSeparator6 = new ns1.BunifuSeparator();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.txtApaterno = new System.Windows.Forms.TextBox();
            this.txtAmaterno = new System.Windows.Forms.TextBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.label5 = new System.Windows.Forms.Label();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.label4 = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.cmdAgregar = new System.Windows.Forms.Panel();
            this.pbAgregar = new System.Windows.Forms.PictureBox();
            this.lblAgregar = new System.Windows.Forms.Label();
            this.txtPais = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.bunifuSeparator20 = new ns1.BunifuSeparator();
            this.txtcp = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.bunifuSeparator19 = new ns1.BunifuSeparator();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.bunifuSeparator18 = new ns1.BunifuSeparator();
            this.label22 = new System.Windows.Forms.Label();
            this.txtExterior = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.bunifuSeparator12 = new ns1.BunifuSeparator();
            this.txtInterior = new System.Windows.Forms.TextBox();
            this.txtColonia = new System.Windows.Forms.TextBox();
            this.txtCalle = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.bunifuSeparator13 = new ns1.BunifuSeparator();
            this.label19 = new System.Windows.Forms.Label();
            this.bunifuSeparator14 = new ns1.BunifuSeparator();
            this.label20 = new System.Windows.Forms.Label();
            this.bunifuSeparator15 = new ns1.BunifuSeparator();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuSeparator16 = new ns1.BunifuSeparator();
            this.pnDatosCuenta = new System.Windows.Forms.Panel();
            this.lblAgregarFoto = new System.Windows.Forms.Label();
            this.pbFoto = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.rdDatosCuenta = new ns1.BunifuElipse(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.bunifuSeparator21 = new ns1.BunifuSeparator();
            this.rdcmdAgregar = new ns1.BunifuElipse(this.components);
            this.cbCiudad = new System.Windows.Forms.ComboBox();
            this.cmdModificar = new System.Windows.Forms.Panel();
            this.pbModificar = new System.Windows.Forms.PictureBox();
            this.lblModificar = new System.Windows.Forms.Label();
            this.cmdBorrar = new System.Windows.Forms.Panel();
            this.pbBorrar = new System.Windows.Forms.PictureBox();
            this.lblBorrar = new System.Windows.Forms.Label();
            this.pnModificar = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.rdEliminar = new ns1.BunifuElipse(this.components);
            this.rdModificar = new ns1.BunifuElipse(this.components);
            this.error1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.encabezado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdCerrar)).BeginInit();
            this.cmdAgregar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAgregar)).BeginInit();
            this.pnDatosCuenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).BeginInit();
            this.cmdModificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbModificar)).BeginInit();
            this.cmdBorrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBorrar)).BeginInit();
            this.pnModificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).BeginInit();
            this.SuspendLayout();
            // 
            // encabezado
            // 
            this.encabezado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.encabezado.Controls.Add(this.pictureBox1);
            this.encabezado.Controls.Add(this.cmdCerrar);
            this.encabezado.Controls.Add(this.lblTitle);
            this.encabezado.Dock = System.Windows.Forms.DockStyle.Top;
            this.encabezado.Location = new System.Drawing.Point(0, 0);
            this.encabezado.Name = "encabezado";
            this.encabezado.Size = new System.Drawing.Size(677, 39);
            this.encabezado.TabIndex = 17;
            this.encabezado.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.perro;
            this.pictureBox1.Location = new System.Drawing.Point(13, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.BackColor = System.Drawing.Color.Transparent;
            this.cmdCerrar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.Equis;
            this.cmdCerrar.ImageActive = null;
            this.cmdCerrar.Location = new System.Drawing.Point(634, 3);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(40, 29);
            this.cmdCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cmdCerrar.TabIndex = 0;
            this.cmdCerrar.TabStop = false;
            this.cmdCerrar.Zoom = 10;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Gadugi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(262, 6);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(199, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "AGREGAR USUARIO";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(462, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 18);
            this.label1.TabIndex = 34;
            this.label1.Text = "Fecha de ingreso:";
            // 
            // dtIngreso
            // 
            this.dtIngreso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(175)))), ((int)(((byte)(107)))));
            this.dtIngreso.BorderRadius = 0;
            this.dtIngreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtIngreso.ForeColor = System.Drawing.Color.White;
            this.dtIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtIngreso.FormatCustom = null;
            this.dtIngreso.Location = new System.Drawing.Point(465, 236);
            this.dtIngreso.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtIngreso.Name = "dtIngreso";
            this.dtIngreso.Size = new System.Drawing.Size(177, 30);
            this.dtIngreso.TabIndex = 8;
            this.dtIngreso.Value = new System.DateTime(2023, 4, 30, 22, 40, 42, 977);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Location = new System.Drawing.Point(462, 144);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 18);
            this.label16.TabIndex = 26;
            this.label16.Text = "Fecha de nacimiento:";
            // 
            // dtNacimiento
            // 
            this.dtNacimiento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.dtNacimiento.BorderRadius = 0;
            this.dtNacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtNacimiento.ForeColor = System.Drawing.Color.White;
            this.dtNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNacimiento.FormatCustom = null;
            this.dtNacimiento.Location = new System.Drawing.Point(465, 163);
            this.dtNacimiento.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtNacimiento.Name = "dtNacimiento";
            this.dtNacimiento.Size = new System.Drawing.Size(178, 30);
            this.dtNacimiento.TabIndex = 5;
            this.dtNacimiento.Value = new System.DateTime(2023, 4, 30, 22, 40, 42, 977);
            // 
            // cbCargo
            // 
            this.cbCargo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbCargo.FormattingEnabled = true;
            this.cbCargo.Location = new System.Drawing.Point(198, 240);
            this.cbCargo.Name = "cbCargo";
            this.cbCargo.Size = new System.Drawing.Size(240, 26);
            this.cbCargo.TabIndex = 7;
            this.cbCargo.Text = "- SELECCIONE CARGO -";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(195, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 18);
            this.label14.TabIndex = 33;
            this.label14.Text = "Cargo:";
            // 
            // txttelefono
            // 
            this.txttelefono.BackColor = System.Drawing.Color.White;
            this.txttelefono.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txttelefono.Location = new System.Drawing.Point(358, 296);
            this.txttelefono.Name = "txttelefono";
            this.txttelefono.Size = new System.Drawing.Size(113, 19);
            this.txttelefono.TabIndex = 10;
            this.txttelefono.Text = "6641978732";
            this.txttelefono.TextChanged += new System.EventHandler(this.txttelefono_TextChanged);
            this.txttelefono.Validating += new System.ComponentModel.CancelEventHandler(this.txttelefono_Validating);
            this.txttelefono.Validated += new System.EventHandler(this.txttelefono_Validated);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(355, 273);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 18);
            this.label10.TabIndex = 35;
            this.label10.Text = "Telefono princial:";
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(359, 311);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(112, 13);
            this.bunifuSeparator8.TabIndex = 36;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = false;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.White;
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCorreo.Location = new System.Drawing.Point(27, 296);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(301, 19);
            this.txtCorreo.TabIndex = 9;
            this.txtCorreo.Text = "SANTOSKARLA122308@GMAIL.COM";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.Location = new System.Drawing.Point(24, 273);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 18);
            this.label13.TabIndex = 31;
            this.label13.Text = "Correo electronico:";
            // 
            // bunifuSeparator11
            // 
            this.bunifuSeparator11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator11.LineThickness = 1;
            this.bunifuSeparator11.Location = new System.Drawing.Point(28, 311);
            this.bunifuSeparator11.Name = "bunifuSeparator11";
            this.bunifuSeparator11.Size = new System.Drawing.Size(300, 13);
            this.bunifuSeparator11.TabIndex = 37;
            this.bunifuSeparator11.Transparency = 255;
            this.bunifuSeparator11.Vertical = false;
            // 
            // txtrfc
            // 
            this.txtrfc.BackColor = System.Drawing.Color.White;
            this.txtrfc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtrfc.Location = new System.Drawing.Point(26, 242);
            this.txtrfc.Name = "txtrfc";
            this.txtrfc.Size = new System.Drawing.Size(145, 19);
            this.txtrfc.TabIndex = 6;
            this.txtrfc.Text = "SARK0312239A5";
            this.txtrfc.TextChanged += new System.EventHandler(this.txtrfc_TextChanged);
            this.txtrfc.Validating += new System.ComponentModel.CancelEventHandler(this.txtrfc_Validating);
            this.txtrfc.Validated += new System.EventHandler(this.txtrfc_Validated);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(23, 219);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 18);
            this.label8.TabIndex = 30;
            this.label8.Text = "RFC:";
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(27, 257);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(144, 13);
            this.bunifuSeparator6.TabIndex = 32;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtID.Location = new System.Drawing.Point(135, 36);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(84, 19);
            this.txtID.TabIndex = 0;
            this.txtID.Text = "122308";
            this.txtID.Validating += new System.ComponentModel.CancelEventHandler(this.txtID_Validating);
            this.txtID.Validated += new System.EventHandler(this.txtID_Validated);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(132, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 18);
            this.label7.TabIndex = 3;
            this.label7.Text = "Usuario ID:";
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(136, 51);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(83, 13);
            this.bunifuSeparator5.TabIndex = 4;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // txtApaterno
            // 
            this.txtApaterno.BackColor = System.Drawing.Color.White;
            this.txtApaterno.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtApaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtApaterno.Location = new System.Drawing.Point(509, 113);
            this.txtApaterno.Name = "txtApaterno";
            this.txtApaterno.Size = new System.Drawing.Size(134, 19);
            this.txtApaterno.TabIndex = 3;
            this.txtApaterno.Text = "DOMINGUEZ";
            this.txtApaterno.TextChanged += new System.EventHandler(this.txtApaterno_TextChanged);
            this.txtApaterno.Validating += new System.ComponentModel.CancelEventHandler(this.txtApaterno_Validating);
            this.txtApaterno.Validated += new System.EventHandler(this.txtApaterno_Validated);
            // 
            // txtAmaterno
            // 
            this.txtAmaterno.BackColor = System.Drawing.Color.White;
            this.txtAmaterno.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtAmaterno.Location = new System.Drawing.Point(305, 167);
            this.txtAmaterno.Name = "txtAmaterno";
            this.txtAmaterno.Size = new System.Drawing.Size(133, 19);
            this.txtAmaterno.TabIndex = 4;
            this.txtAmaterno.Text = "SANTILLANA";
            this.txtAmaterno.TextChanged += new System.EventHandler(this.txtAmaterno_TextChanged);
            this.txtAmaterno.Validating += new System.ComponentModel.CancelEventHandler(this.txtAmaterno_Validating);
            this.txtAmaterno.Validated += new System.EventHandler(this.txtAmaterno_Validated);
            // 
            // txtContraseña
            // 
            this.txtContraseña.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtContraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtContraseña.Location = new System.Drawing.Point(135, 90);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(120, 19);
            this.txtContraseña.TabIndex = 1;
            this.txtContraseña.Text = "contraseña";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(301, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 18);
            this.label6.TabIndex = 28;
            this.label6.Text = "Apellido Materno:";
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(305, 182);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(132, 13);
            this.bunifuSeparator4.TabIndex = 29;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(505, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 18);
            this.label5.TabIndex = 24;
            this.label5.Text = "Apellido Paterno:";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(509, 128);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(133, 13);
            this.bunifuSeparator3.TabIndex = 25;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.IndianRed;
            this.label4.Location = new System.Drawing.Point(68, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "DATOS  DE CUENTA";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator1.LineThickness = 4;
            this.bunifuSeparator1.Location = new System.Drawing.Point(291, 59);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(365, 17);
            this.bunifuSeparator1.TabIndex = 20;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(132, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Contraseña:";
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(136, 105);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(119, 13);
            this.bunifuSeparator2.TabIndex = 6;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.cmdAgregar.Controls.Add(this.pbAgregar);
            this.cmdAgregar.Controls.Add(this.lblAgregar);
            this.cmdAgregar.Location = new System.Drawing.Point(278, 495);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(81, 72);
            this.cmdAgregar.TabIndex = 55;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // pbAgregar
            // 
            this.pbAgregar.Image = ((System.Drawing.Image)(resources.GetObject("pbAgregar.Image")));
            this.pbAgregar.Location = new System.Drawing.Point(23, 11);
            this.pbAgregar.Name = "pbAgregar";
            this.pbAgregar.Size = new System.Drawing.Size(38, 39);
            this.pbAgregar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbAgregar.TabIndex = 111;
            this.pbAgregar.TabStop = false;
            this.pbAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // lblAgregar
            // 
            this.lblAgregar.AutoSize = true;
            this.lblAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgregar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblAgregar.Location = new System.Drawing.Point(12, 50);
            this.lblAgregar.Name = "lblAgregar";
            this.lblAgregar.Size = new System.Drawing.Size(59, 17);
            this.lblAgregar.TabIndex = 0;
            this.lblAgregar.Text = "Agregar";
            this.lblAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // txtPais
            // 
            this.txtPais.BackColor = System.Drawing.Color.White;
            this.txtPais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPais.Location = new System.Drawing.Point(495, 440);
            this.txtPais.Name = "txtPais";
            this.txtPais.ReadOnly = true;
            this.txtPais.Size = new System.Drawing.Size(162, 19);
            this.txtPais.TabIndex = 18;
            this.txtPais.Text = "MÉXICO";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label25.Location = new System.Drawing.Point(492, 417);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 18);
            this.label25.TabIndex = 49;
            this.label25.Text = "Pais:";
            // 
            // bunifuSeparator20
            // 
            this.bunifuSeparator20.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator20.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator20.LineThickness = 1;
            this.bunifuSeparator20.Location = new System.Drawing.Point(496, 455);
            this.bunifuSeparator20.Name = "bunifuSeparator20";
            this.bunifuSeparator20.Size = new System.Drawing.Size(161, 13);
            this.bunifuSeparator20.TabIndex = 50;
            this.bunifuSeparator20.Transparency = 255;
            this.bunifuSeparator20.Vertical = false;
            // 
            // txtcp
            // 
            this.txtcp.BackColor = System.Drawing.Color.White;
            this.txtcp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtcp.Location = new System.Drawing.Point(31, 440);
            this.txtcp.Name = "txtcp";
            this.txtcp.Size = new System.Drawing.Size(59, 19);
            this.txtcp.TabIndex = 15;
            this.txtcp.Text = "22330";
            this.txtcp.TextChanged += new System.EventHandler(this.txtcp_TextChanged);
            this.txtcp.Validating += new System.ComponentModel.CancelEventHandler(this.txtcp_Validating);
            this.txtcp.Validated += new System.EventHandler(this.txtcp_Validated);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label24.Location = new System.Drawing.Point(26, 417);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 18);
            this.label24.TabIndex = 52;
            this.label24.Text = "C.P.:";
            // 
            // bunifuSeparator19
            // 
            this.bunifuSeparator19.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator19.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator19.LineThickness = 1;
            this.bunifuSeparator19.Location = new System.Drawing.Point(30, 455);
            this.bunifuSeparator19.Name = "bunifuSeparator19";
            this.bunifuSeparator19.Size = new System.Drawing.Size(58, 13);
            this.bunifuSeparator19.TabIndex = 54;
            this.bunifuSeparator19.Transparency = 255;
            this.bunifuSeparator19.Vertical = false;
            // 
            // txtEstado
            // 
            this.txtEstado.BackColor = System.Drawing.Color.White;
            this.txtEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEstado.Location = new System.Drawing.Point(306, 440);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.ReadOnly = true;
            this.txtEstado.Size = new System.Drawing.Size(168, 19);
            this.txtEstado.TabIndex = 17;
            this.txtEstado.Text = "BAJA CALIFORNIA";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label23.Location = new System.Drawing.Point(303, 417);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 18);
            this.label23.TabIndex = 47;
            this.label23.Text = "Estado:";
            // 
            // bunifuSeparator18
            // 
            this.bunifuSeparator18.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator18.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator18.LineThickness = 1;
            this.bunifuSeparator18.Location = new System.Drawing.Point(307, 455);
            this.bunifuSeparator18.Name = "bunifuSeparator18";
            this.bunifuSeparator18.Size = new System.Drawing.Size(167, 13);
            this.bunifuSeparator18.TabIndex = 48;
            this.bunifuSeparator18.Transparency = 255;
            this.bunifuSeparator18.Vertical = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label22.Location = new System.Drawing.Point(107, 417);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 18);
            this.label22.TabIndex = 51;
            this.label22.Text = "Ciudad:";
            // 
            // txtExterior
            // 
            this.txtExterior.BackColor = System.Drawing.Color.White;
            this.txtExterior.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtExterior.Location = new System.Drawing.Point(248, 386);
            this.txtExterior.Name = "txtExterior";
            this.txtExterior.Size = new System.Drawing.Size(88, 19);
            this.txtExterior.TabIndex = 12;
            this.txtExterior.Text = "5714";
            this.txtExterior.TextChanged += new System.EventHandler(this.txtExterior_TextChanged);
            this.txtExterior.Validating += new System.ComponentModel.CancelEventHandler(this.txtExterior_Validating);
            this.txtExterior.Validated += new System.EventHandler(this.txtExterior_Validated);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Location = new System.Drawing.Point(245, 363);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 18);
            this.label17.TabIndex = 41;
            this.label17.Text = "No. Exterior:";
            // 
            // bunifuSeparator12
            // 
            this.bunifuSeparator12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator12.LineThickness = 1;
            this.bunifuSeparator12.Location = new System.Drawing.Point(249, 401);
            this.bunifuSeparator12.Name = "bunifuSeparator12";
            this.bunifuSeparator12.Size = new System.Drawing.Size(87, 13);
            this.bunifuSeparator12.TabIndex = 42;
            this.bunifuSeparator12.Transparency = 255;
            this.bunifuSeparator12.Vertical = false;
            // 
            // txtInterior
            // 
            this.txtInterior.BackColor = System.Drawing.Color.White;
            this.txtInterior.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtInterior.Location = new System.Drawing.Point(362, 386);
            this.txtInterior.Name = "txtInterior";
            this.txtInterior.Size = new System.Drawing.Size(78, 19);
            this.txtInterior.TabIndex = 13;
            this.txtInterior.TextChanged += new System.EventHandler(this.txtInterior_TextChanged);
            this.txtInterior.Validating += new System.ComponentModel.CancelEventHandler(this.txtInterior_Validating);
            this.txtInterior.Validated += new System.EventHandler(this.txtInterior_Validated);
            // 
            // txtColonia
            // 
            this.txtColonia.BackColor = System.Drawing.Color.White;
            this.txtColonia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColonia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtColonia.Location = new System.Drawing.Point(467, 386);
            this.txtColonia.Name = "txtColonia";
            this.txtColonia.Size = new System.Drawing.Size(192, 19);
            this.txtColonia.TabIndex = 14;
            this.txtColonia.Text = "VISTA DEL VALLE";
            this.txtColonia.TextChanged += new System.EventHandler(this.txtColonia_TextChanged);
            this.txtColonia.Validating += new System.ComponentModel.CancelEventHandler(this.txtColonia_Validating);
            this.txtColonia.Validated += new System.EventHandler(this.txtColonia_Validated);
            // 
            // txtCalle
            // 
            this.txtCalle.BackColor = System.Drawing.Color.White;
            this.txtCalle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCalle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCalle.Location = new System.Drawing.Point(29, 386);
            this.txtCalle.Name = "txtCalle";
            this.txtCalle.Size = new System.Drawing.Size(192, 19);
            this.txtCalle.TabIndex = 11;
            this.txtCalle.Text = "VALLE ENCANTADO";
            this.txtCalle.TextChanged += new System.EventHandler(this.txtCalle_TextChanged);
            this.txtCalle.Validating += new System.ComponentModel.CancelEventHandler(this.txtCalle_Validating);
            this.txtCalle.Validated += new System.EventHandler(this.txtCalle_Validated);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label18.Location = new System.Drawing.Point(463, 363);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 18);
            this.label18.TabIndex = 44;
            this.label18.Text = "Colonia:";
            // 
            // bunifuSeparator13
            // 
            this.bunifuSeparator13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator13.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator13.LineThickness = 1;
            this.bunifuSeparator13.Location = new System.Drawing.Point(467, 401);
            this.bunifuSeparator13.Name = "bunifuSeparator13";
            this.bunifuSeparator13.Size = new System.Drawing.Size(191, 13);
            this.bunifuSeparator13.TabIndex = 45;
            this.bunifuSeparator13.Transparency = 255;
            this.bunifuSeparator13.Vertical = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Location = new System.Drawing.Point(358, 363);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 18);
            this.label19.TabIndex = 43;
            this.label19.Text = "No. Interior:";
            // 
            // bunifuSeparator14
            // 
            this.bunifuSeparator14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator14.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator14.LineThickness = 1;
            this.bunifuSeparator14.Location = new System.Drawing.Point(362, 401);
            this.bunifuSeparator14.Name = "bunifuSeparator14";
            this.bunifuSeparator14.Size = new System.Drawing.Size(77, 13);
            this.bunifuSeparator14.TabIndex = 46;
            this.bunifuSeparator14.Transparency = 255;
            this.bunifuSeparator14.Vertical = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label20.Location = new System.Drawing.Point(26, 363);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 18);
            this.label20.TabIndex = 39;
            this.label20.Text = "Calle:";
            // 
            // bunifuSeparator15
            // 
            this.bunifuSeparator15.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator15.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator15.LineThickness = 1;
            this.bunifuSeparator15.Location = new System.Drawing.Point(30, 401);
            this.bunifuSeparator15.Name = "bunifuSeparator15";
            this.bunifuSeparator15.Size = new System.Drawing.Size(191, 13);
            this.bunifuSeparator15.TabIndex = 53;
            this.bunifuSeparator15.Transparency = 255;
            this.bunifuSeparator15.Vertical = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.IndianRed;
            this.label21.Location = new System.Drawing.Point(237, 340);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(205, 20);
            this.label21.TabIndex = 40;
            this.label21.Text = "DIRECCION PARTICULAR";
            // 
            // bunifuSeparator16
            // 
            this.bunifuSeparator16.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator16.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator16.LineThickness = 4;
            this.bunifuSeparator16.Location = new System.Drawing.Point(18, 343);
            this.bunifuSeparator16.Name = "bunifuSeparator16";
            this.bunifuSeparator16.Size = new System.Drawing.Size(638, 10);
            this.bunifuSeparator16.TabIndex = 38;
            this.bunifuSeparator16.Transparency = 255;
            this.bunifuSeparator16.Vertical = false;
            // 
            // pnDatosCuenta
            // 
            this.pnDatosCuenta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.pnDatosCuenta.Controls.Add(this.lblAgregarFoto);
            this.pnDatosCuenta.Controls.Add(this.pbFoto);
            this.pnDatosCuenta.Controls.Add(this.txtID);
            this.pnDatosCuenta.Controls.Add(this.label7);
            this.pnDatosCuenta.Controls.Add(this.bunifuSeparator5);
            this.pnDatosCuenta.Controls.Add(this.txtContraseña);
            this.pnDatosCuenta.Controls.Add(this.label2);
            this.pnDatosCuenta.Controls.Add(this.bunifuSeparator2);
            this.pnDatosCuenta.Location = new System.Drawing.Point(0, 77);
            this.pnDatosCuenta.Name = "pnDatosCuenta";
            this.pnDatosCuenta.Size = new System.Drawing.Size(272, 125);
            this.pnDatosCuenta.TabIndex = 1;
            // 
            // lblAgregarFoto
            // 
            this.lblAgregarFoto.AutoSize = true;
            this.lblAgregarFoto.Location = new System.Drawing.Point(41, 79);
            this.lblAgregarFoto.Name = "lblAgregarFoto";
            this.lblAgregarFoto.Size = new System.Drawing.Size(65, 13);
            this.lblAgregarFoto.TabIndex = 2;
            this.lblAgregarFoto.Text = "Agregar foto";
            // 
            // pbFoto
            // 
            this.pbFoto.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.estilo_grafico;
            this.pbFoto.Location = new System.Drawing.Point(22, 13);
            this.pbFoto.Name = "pbFoto";
            this.pbFoto.Size = new System.Drawing.Size(100, 100);
            this.pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbFoto.TabIndex = 178;
            this.pbFoto.TabStop = false;
            this.pbFoto.Click += new System.EventHandler(this.pbFoto_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.IndianRed;
            this.label28.Location = new System.Drawing.Point(400, 56);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(177, 20);
            this.label28.TabIndex = 21;
            this.label28.Text = "DATOS PERSONALES";
            // 
            // rdDatosCuenta
            // 
            this.rdDatosCuenta.ElipseRadius = 20;
            this.rdDatosCuenta.TargetControl = this.pnDatosCuenta;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.panel2.Location = new System.Drawing.Point(0, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(16, 122);
            this.panel2.TabIndex = 19;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.White;
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre.Location = new System.Drawing.Point(305, 113);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(177, 19);
            this.txtNombre.TabIndex = 2;
            this.txtNombre.Text = "DOMINGUEZ";
            this.txtNombre.TextChanged += new System.EventHandler(this.txtNombre_TextChanged);
            this.txtNombre.Validating += new System.ComponentModel.CancelEventHandler(this.txtNombre_Validating);
            this.txtNombre.Validated += new System.EventHandler(this.txtNombre_Validated);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label29.Location = new System.Drawing.Point(301, 90);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(84, 18);
            this.label29.TabIndex = 23;
            this.label29.Text = "Nombre(s):";
            // 
            // bunifuSeparator21
            // 
            this.bunifuSeparator21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator21.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator21.LineThickness = 1;
            this.bunifuSeparator21.Location = new System.Drawing.Point(305, 128);
            this.bunifuSeparator21.Name = "bunifuSeparator21";
            this.bunifuSeparator21.Size = new System.Drawing.Size(176, 13);
            this.bunifuSeparator21.TabIndex = 27;
            this.bunifuSeparator21.Transparency = 255;
            this.bunifuSeparator21.Vertical = false;
            // 
            // rdcmdAgregar
            // 
            this.rdcmdAgregar.ElipseRadius = 30;
            this.rdcmdAgregar.TargetControl = this.cmdAgregar;
            // 
            // cbCiudad
            // 
            this.cbCiudad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbCiudad.FormattingEnabled = true;
            this.cbCiudad.Location = new System.Drawing.Point(110, 438);
            this.cbCiudad.Name = "cbCiudad";
            this.cbCiudad.Size = new System.Drawing.Size(177, 26);
            this.cbCiudad.TabIndex = 16;
            this.cbCiudad.Text = "- SELECCIONE CIUDAD-";
            this.cbCiudad.SelectedIndexChanged += new System.EventHandler(this.cbCiudad_SelectedIndexChanged);
            // 
            // cmdModificar
            // 
            this.cmdModificar.BackColor = System.Drawing.Color.MistyRose;
            this.cmdModificar.Controls.Add(this.pbModificar);
            this.cmdModificar.Controls.Add(this.lblModificar);
            this.cmdModificar.Location = new System.Drawing.Point(17, 12);
            this.cmdModificar.Name = "cmdModificar";
            this.cmdModificar.Size = new System.Drawing.Size(81, 72);
            this.cmdModificar.TabIndex = 188;
            this.cmdModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // pbModificar
            // 
            this.pbModificar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.editar__1_;
            this.pbModificar.Location = new System.Drawing.Point(22, 7);
            this.pbModificar.Name = "pbModificar";
            this.pbModificar.Size = new System.Drawing.Size(38, 39);
            this.pbModificar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbModificar.TabIndex = 111;
            this.pbModificar.TabStop = false;
            this.pbModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // lblModificar
            // 
            this.lblModificar.AutoSize = true;
            this.lblModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModificar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblModificar.Location = new System.Drawing.Point(9, 44);
            this.lblModificar.Name = "lblModificar";
            this.lblModificar.Size = new System.Drawing.Size(65, 17);
            this.lblModificar.TabIndex = 0;
            this.lblModificar.Text = "Modificar";
            this.lblModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // cmdBorrar
            // 
            this.cmdBorrar.BackColor = System.Drawing.Color.MistyRose;
            this.cmdBorrar.Controls.Add(this.pbBorrar);
            this.cmdBorrar.Controls.Add(this.lblBorrar);
            this.cmdBorrar.Location = new System.Drawing.Point(146, 12);
            this.cmdBorrar.Name = "cmdBorrar";
            this.cmdBorrar.Size = new System.Drawing.Size(81, 72);
            this.cmdBorrar.TabIndex = 189;
            // 
            // pbBorrar
            // 
            this.pbBorrar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.borrar__1_;
            this.pbBorrar.Location = new System.Drawing.Point(18, 6);
            this.pbBorrar.Name = "pbBorrar";
            this.pbBorrar.Size = new System.Drawing.Size(44, 41);
            this.pbBorrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBorrar.TabIndex = 111;
            this.pbBorrar.TabStop = false;
            this.pbBorrar.Click += new System.EventHandler(this.pbBorrar_Click);
            // 
            // lblBorrar
            // 
            this.lblBorrar.AutoSize = true;
            this.lblBorrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBorrar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblBorrar.Location = new System.Drawing.Point(13, 45);
            this.lblBorrar.Name = "lblBorrar";
            this.lblBorrar.Size = new System.Drawing.Size(58, 17);
            this.lblBorrar.TabIndex = 0;
            this.lblBorrar.Text = "Eliminar";
            // 
            // pnModificar
            // 
            this.pnModificar.Controls.Add(this.cmdBorrar);
            this.pnModificar.Controls.Add(this.cmdModificar);
            this.pnModificar.Location = new System.Drawing.Point(223, 485);
            this.pnModificar.Name = "pnModificar";
            this.pnModificar.Size = new System.Drawing.Size(242, 96);
            this.pnModificar.TabIndex = 190;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(532, 414);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 21);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 187;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(361, 414);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(21, 21);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 186;
            this.pictureBox4.TabStop = false;
            // 
            // rdEliminar
            // 
            this.rdEliminar.ElipseRadius = 70;
            this.rdEliminar.TargetControl = this.cmdBorrar;
            // 
            // rdModificar
            // 
            this.rdModificar.ElipseRadius = 70;
            this.rdModificar.TargetControl = this.cmdModificar;
            // 
            // error1
            // 
            this.error1.ContainerControl = this;
            // 
            // frmEdit_Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(677, 593);
            this.Controls.Add(this.pnModificar);
            this.Controls.Add(this.cbCiudad);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.bunifuSeparator21);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.pnDatosCuenta);
            this.Controls.Add(this.cmdAgregar);
            this.Controls.Add(this.txtPais);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.bunifuSeparator20);
            this.Controls.Add(this.txtcp);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.bunifuSeparator19);
            this.Controls.Add(this.txtEstado);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.bunifuSeparator18);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtExterior);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.bunifuSeparator12);
            this.Controls.Add(this.txtInterior);
            this.Controls.Add(this.txtColonia);
            this.Controls.Add(this.txtCalle);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.bunifuSeparator13);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.bunifuSeparator14);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.bunifuSeparator15);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.bunifuSeparator16);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtIngreso);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dtNacimiento);
            this.Controls.Add(this.cbCargo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txttelefono);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.bunifuSeparator8);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.bunifuSeparator11);
            this.Controls.Add(this.txtrfc);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.bunifuSeparator6);
            this.Controls.Add(this.txtApaterno);
            this.Controls.Add(this.txtAmaterno);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bunifuSeparator4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bunifuSeparator3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.encabezado);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmEdit_Usuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmUsuario";
            this.Load += new System.EventHandler(this.frmEdit_Usuario_Load);
            this.encabezado.ResumeLayout(false);
            this.encabezado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdCerrar)).EndInit();
            this.cmdAgregar.ResumeLayout(false);
            this.cmdAgregar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAgregar)).EndInit();
            this.pnDatosCuenta.ResumeLayout(false);
            this.pnDatosCuenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).EndInit();
            this.cmdModificar.ResumeLayout(false);
            this.cmdModificar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbModificar)).EndInit();
            this.cmdBorrar.ResumeLayout(false);
            this.cmdBorrar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBorrar)).EndInit();
            this.pnModificar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel encabezado;
        public System.Windows.Forms.PictureBox pictureBox1;
        public ns1.BunifuImageButton cmdCerrar;
        public System.Windows.Forms.Label lblTitle;
        public System.Windows.Forms.Label label1;
        public ns1.BunifuDatepicker dtIngreso;
        public System.Windows.Forms.Label label16;
        public ns1.BunifuDatepicker dtNacimiento;
        public System.Windows.Forms.ComboBox cbCargo;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.TextBox txttelefono;
        public System.Windows.Forms.Label label10;
        public ns1.BunifuSeparator bunifuSeparator8;
        public System.Windows.Forms.TextBox txtCorreo;
        public System.Windows.Forms.Label label13;
        public ns1.BunifuSeparator bunifuSeparator11;
        public System.Windows.Forms.TextBox txtrfc;
        public System.Windows.Forms.Label label8;
        public ns1.BunifuSeparator bunifuSeparator6;
        public System.Windows.Forms.TextBox txtID;
        public System.Windows.Forms.Label label7;
        public ns1.BunifuSeparator bunifuSeparator5;
        public System.Windows.Forms.TextBox txtApaterno;
        public System.Windows.Forms.TextBox txtAmaterno;
        public System.Windows.Forms.TextBox txtContraseña;
        public System.Windows.Forms.Label label6;
        public ns1.BunifuSeparator bunifuSeparator4;
        public System.Windows.Forms.Label label5;
        public ns1.BunifuSeparator bunifuSeparator3;
        public System.Windows.Forms.Label label4;
        public ns1.BunifuSeparator bunifuSeparator1;
        public System.Windows.Forms.Label label2;
        public ns1.BunifuSeparator bunifuSeparator2;
        public System.Windows.Forms.Panel cmdAgregar;
        public System.Windows.Forms.PictureBox pbAgregar;
        public System.Windows.Forms.Label lblAgregar;
        public System.Windows.Forms.TextBox txtPais;
        public System.Windows.Forms.Label label25;
        public ns1.BunifuSeparator bunifuSeparator20;
        public System.Windows.Forms.TextBox txtcp;
        public System.Windows.Forms.Label label24;
        public ns1.BunifuSeparator bunifuSeparator19;
        public System.Windows.Forms.TextBox txtEstado;
        public System.Windows.Forms.Label label23;
        public ns1.BunifuSeparator bunifuSeparator18;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.TextBox txtExterior;
        public System.Windows.Forms.Label label17;
        public ns1.BunifuSeparator bunifuSeparator12;
        public System.Windows.Forms.TextBox txtInterior;
        public System.Windows.Forms.TextBox txtColonia;
        public System.Windows.Forms.TextBox txtCalle;
        public System.Windows.Forms.Label label18;
        public ns1.BunifuSeparator bunifuSeparator13;
        public System.Windows.Forms.Label label19;
        public ns1.BunifuSeparator bunifuSeparator14;
        public System.Windows.Forms.Label label20;
        public ns1.BunifuSeparator bunifuSeparator15;
        public System.Windows.Forms.Label label21;
        public ns1.BunifuSeparator bunifuSeparator16;
        public System.Windows.Forms.PictureBox pbFoto;
        public System.Windows.Forms.Panel pnDatosCuenta;
        public System.Windows.Forms.Label label28;
        public ns1.BunifuElipse rdDatosCuenta;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.TextBox txtNombre;
        public System.Windows.Forms.Label label29;
        public ns1.BunifuSeparator bunifuSeparator21;
        public System.Windows.Forms.Label lblAgregarFoto;
        public ns1.BunifuElipse rdcmdAgregar;
        public System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.ComboBox cbCiudad;
        public System.Windows.Forms.Panel cmdModificar;
        public System.Windows.Forms.PictureBox pbModificar;
        public System.Windows.Forms.Label lblModificar;
        public System.Windows.Forms.Panel cmdBorrar;
        public System.Windows.Forms.PictureBox pbBorrar;
        public System.Windows.Forms.Label lblBorrar;
        private System.Windows.Forms.Panel pnModificar;
        private ns1.BunifuElipse rdEliminar;
        private ns1.BunifuElipse rdModificar;
        private System.Windows.Forms.ErrorProvider error1;
    }
}