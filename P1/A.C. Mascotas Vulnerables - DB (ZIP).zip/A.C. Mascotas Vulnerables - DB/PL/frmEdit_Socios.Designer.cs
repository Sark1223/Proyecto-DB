﻿namespace A.C.Mascotas_Vulnerables___DB.PL
{
    partial class frmEdit_Socios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEdit_Socios));
            this.rdSocios = new ns1.BunifuElipse(this.components);
            this.encabezado = new System.Windows.Forms.Panel();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.cmdCerrar = new ns1.BunifuImageButton();
            this.lblTitle = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.lblNombreSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.label4 = new System.Windows.Forms.Label();
            this.lblApellidoPSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.lblApellidoMSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.txtNombreSocio = new System.Windows.Forms.TextBox();
            this.txtApellidoMSocio = new System.Windows.Forms.TextBox();
            this.txtApellidoPSocio = new System.Windows.Forms.TextBox();
            this.txtSocioID = new System.Windows.Forms.TextBox();
            this.lblSocioID = new System.Windows.Forms.Label();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.txtRfcSocio = new System.Windows.Forms.TextBox();
            this.lblRfcSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator6 = new ns1.BunifuSeparator();
            this.txtTelefonoPSocio = new System.Windows.Forms.TextBox();
            this.lblTelefonoPSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator8 = new ns1.BunifuSeparator();
            this.txtTelefono2Socio = new System.Windows.Forms.TextBox();
            this.txtTelefono3Socio = new System.Windows.Forms.TextBox();
            this.txtCorreoSocio = new System.Windows.Forms.TextBox();
            this.lblTelefono3Socio = new System.Windows.Forms.Label();
            this.bunifuSeparator9 = new ns1.BunifuSeparator();
            this.lblTelefono2Socio = new System.Windows.Forms.Label();
            this.bunifuSeparator10 = new ns1.BunifuSeparator();
            this.lblCorreoSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator11 = new ns1.BunifuSeparator();
            this.lblTipoPSocio = new System.Windows.Forms.Label();
            this.cbTipoPSocio = new System.Windows.Forms.ComboBox();
            this.cbEstadoSocio = new System.Windows.Forms.ComboBox();
            this.lblEstadoSocio = new System.Windows.Forms.Label();
            this.dpFechaNSocio = new ns1.BunifuDatepicker();
            this.lblFechaNSocio = new System.Windows.Forms.Label();
            this.txtNoExtSocio = new System.Windows.Forms.TextBox();
            this.lblNoExtSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator12 = new ns1.BunifuSeparator();
            this.txtNoIntSocio = new System.Windows.Forms.TextBox();
            this.txtColoniaSocio = new System.Windows.Forms.TextBox();
            this.txtCalleSocio = new System.Windows.Forms.TextBox();
            this.lblColoniaSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator13 = new ns1.BunifuSeparator();
            this.lblNoIntSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator14 = new ns1.BunifuSeparator();
            this.lblCalleSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator15 = new ns1.BunifuSeparator();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuSeparator16 = new ns1.BunifuSeparator();
            this.txtCpSocio = new System.Windows.Forms.TextBox();
            this.lblCpSocio = new System.Windows.Forms.Label();
            this.bunifuSeparator19 = new ns1.BunifuSeparator();
            this.bunifuSeparator7 = new ns1.BunifuSeparator();
            this.label9 = new System.Windows.Forms.Label();
            this.lblFechaISocio = new System.Windows.Forms.Label();
            this.dpFechaISocio = new ns1.BunifuDatepicker();
            this.lblAgregar = new System.Windows.Forms.Label();
            this.cmdAgregar = new System.Windows.Forms.Panel();
            this.pbAgregar = new System.Windows.Forms.PictureBox();
            this.rdcmdAgregar = new ns1.BunifuElipse(this.components);
            this.cbCiudad = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtPais = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.bunifuSeparator20 = new ns1.BunifuSeparator();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.bunifuSeparator18 = new ns1.BunifuSeparator();
            this.label22 = new System.Windows.Forms.Label();
            this.pnModificar = new System.Windows.Forms.Panel();
            this.cmdBorrar = new System.Windows.Forms.Panel();
            this.pbBorrar = new System.Windows.Forms.PictureBox();
            this.lblBorrar = new System.Windows.Forms.Label();
            this.cmdModificar = new System.Windows.Forms.Panel();
            this.pbModificar = new System.Windows.Forms.PictureBox();
            this.lblModificar = new System.Windows.Forms.Label();
            this.error1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.error2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.encabezado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdCerrar)).BeginInit();
            this.cmdAgregar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAgregar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pnModificar.SuspendLayout();
            this.cmdBorrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBorrar)).BeginInit();
            this.cmdModificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbModificar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error2)).BeginInit();
            this.SuspendLayout();
            // 
            // rdSocios
            // 
            this.rdSocios.ElipseRadius = 30;
            this.rdSocios.TargetControl = this;
            // 
            // encabezado
            // 
            this.encabezado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.encabezado.Controls.Add(this.pbLogo);
            this.encabezado.Controls.Add(this.cmdCerrar);
            this.encabezado.Controls.Add(this.lblTitle);
            this.encabezado.Dock = System.Windows.Forms.DockStyle.Top;
            this.encabezado.Location = new System.Drawing.Point(0, 0);
            this.encabezado.Name = "encabezado";
            this.encabezado.Size = new System.Drawing.Size(696, 39);
            this.encabezado.TabIndex = 1;
            this.encabezado.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // pbLogo
            // 
            this.pbLogo.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.perro;
            this.pbLogo.Location = new System.Drawing.Point(13, 6);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(34, 28);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 1;
            this.pbLogo.TabStop = false;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.BackColor = System.Drawing.Color.Transparent;
            this.cmdCerrar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.Equis;
            this.cmdCerrar.ImageActive = null;
            this.cmdCerrar.Location = new System.Drawing.Point(651, 4);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(40, 29);
            this.cmdCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cmdCerrar.TabIndex = 0;
            this.cmdCerrar.TabStop = false;
            this.cmdCerrar.Zoom = 10;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Gadugi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(232, 6);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(249, 25);
            this.lblTitle.TabIndex = 44;
            this.lblTitle.Text = "AGREGAR NUEVO SOCIO";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(146, 123);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(171, 13);
            this.bunifuSeparator2.TabIndex = 42;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // lblNombreSocio
            // 
            this.lblNombreSocio.AutoSize = true;
            this.lblNombreSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNombreSocio.Location = new System.Drawing.Point(142, 85);
            this.lblNombreSocio.Name = "lblNombreSocio";
            this.lblNombreSocio.Size = new System.Drawing.Size(84, 18);
            this.lblNombreSocio.TabIndex = 40;
            this.lblNombreSocio.Text = "Nombre(s):";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator1.LineThickness = 4;
            this.bunifuSeparator1.Location = new System.Drawing.Point(28, 56);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(638, 10);
            this.bunifuSeparator1.TabIndex = 45;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.IndianRed;
            this.label4.Location = new System.Drawing.Point(271, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 20);
            this.label4.TabIndex = 46;
            this.label4.Text = "DATOS PERSONALES";
            // 
            // lblApellidoPSocio
            // 
            this.lblApellidoPSocio.AutoSize = true;
            this.lblApellidoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidoPSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblApellidoPSocio.Location = new System.Drawing.Point(339, 85);
            this.lblApellidoPSocio.Name = "lblApellidoPSocio";
            this.lblApellidoPSocio.Size = new System.Drawing.Size(119, 18);
            this.lblApellidoPSocio.TabIndex = 47;
            this.lblApellidoPSocio.Text = "Apellido Paterno:";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(343, 123);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(133, 13);
            this.bunifuSeparator3.TabIndex = 49;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // lblApellidoMSocio
            // 
            this.lblApellidoMSocio.AutoSize = true;
            this.lblApellidoMSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidoMSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblApellidoMSocio.Location = new System.Drawing.Point(510, 85);
            this.lblApellidoMSocio.Name = "lblApellidoMSocio";
            this.lblApellidoMSocio.Size = new System.Drawing.Size(122, 18);
            this.lblApellidoMSocio.TabIndex = 50;
            this.lblApellidoMSocio.Text = "Apellido Materno:";
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(514, 123);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(132, 13);
            this.bunifuSeparator4.TabIndex = 52;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // txtNombreSocio
            // 
            this.txtNombreSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNombreSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombreSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombreSocio.Location = new System.Drawing.Point(145, 108);
            this.txtNombreSocio.Name = "txtNombreSocio";
            this.txtNombreSocio.Size = new System.Drawing.Size(172, 19);
            this.txtNombreSocio.TabIndex = 53;
            this.txtNombreSocio.Text = "karla judith";
            this.txtNombreSocio.TextChanged += new System.EventHandler(this.txtNombreSocio_TextChanged);
            this.txtNombreSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtNombreSocio_Validating);
            this.txtNombreSocio.Validated += new System.EventHandler(this.txtNombreSocio_Validated);
            // 
            // txtApellidoMSocio
            // 
            this.txtApellidoMSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtApellidoMSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtApellidoMSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtApellidoMSocio.Location = new System.Drawing.Point(514, 108);
            this.txtApellidoMSocio.Name = "txtApellidoMSocio";
            this.txtApellidoMSocio.Size = new System.Drawing.Size(133, 19);
            this.txtApellidoMSocio.TabIndex = 54;
            this.txtApellidoMSocio.Text = "santillana";
            this.txtApellidoMSocio.TextChanged += new System.EventHandler(this.txtApellidoMSocio_TextChanged);
            this.txtApellidoMSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtApellidoMSocio_Validating);
            this.txtApellidoMSocio.Validated += new System.EventHandler(this.txtApellidoMSocio_Validated);
            // 
            // txtApellidoPSocio
            // 
            this.txtApellidoPSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtApellidoPSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtApellidoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtApellidoPSocio.Location = new System.Drawing.Point(343, 108);
            this.txtApellidoPSocio.Name = "txtApellidoPSocio";
            this.txtApellidoPSocio.Size = new System.Drawing.Size(134, 19);
            this.txtApellidoPSocio.TabIndex = 55;
            this.txtApellidoPSocio.Text = "dominguez";
            this.txtApellidoPSocio.TextChanged += new System.EventHandler(this.txtApellidoPSocio_TextChanged);
            this.txtApellidoPSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtApellidoPSocio_Validating);
            this.txtApellidoPSocio.Validated += new System.EventHandler(this.txtApellidoPSocio_Validated);
            // 
            // txtSocioID
            // 
            this.txtSocioID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtSocioID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSocioID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtSocioID.Location = new System.Drawing.Point(33, 108);
            this.txtSocioID.Name = "txtSocioID";
            this.txtSocioID.Size = new System.Drawing.Size(84, 19);
            this.txtSocioID.TabIndex = 58;
            this.txtSocioID.Text = "12";
            this.txtSocioID.TextChanged += new System.EventHandler(this.txtSocioID_TextChanged);
            this.txtSocioID.Validating += new System.ComponentModel.CancelEventHandler(this.txtSocioID_Validating);
            this.txtSocioID.Validated += new System.EventHandler(this.txtSocioID_Validated);
            // 
            // lblSocioID
            // 
            this.lblSocioID.AutoSize = true;
            this.lblSocioID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSocioID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSocioID.Location = new System.Drawing.Point(30, 85);
            this.lblSocioID.Name = "lblSocioID";
            this.lblSocioID.Size = new System.Drawing.Size(69, 18);
            this.lblSocioID.TabIndex = 56;
            this.lblSocioID.Text = "Socio ID:";
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(34, 123);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(83, 13);
            this.bunifuSeparator5.TabIndex = 57;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // txtRfcSocio
            // 
            this.txtRfcSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtRfcSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRfcSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtRfcSocio.Location = new System.Drawing.Point(33, 168);
            this.txtRfcSocio.Name = "txtRfcSocio";
            this.txtRfcSocio.Size = new System.Drawing.Size(145, 19);
            this.txtRfcSocio.TabIndex = 61;
            this.txtRfcSocio.Text = "sark0312239a5";
            this.txtRfcSocio.TextChanged += new System.EventHandler(this.txtRfcSocio_TextChanged);
            this.txtRfcSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtRfcSocio_Validating);
            this.txtRfcSocio.Validated += new System.EventHandler(this.txtRfcSocio_Validated);
            // 
            // lblRfcSocio
            // 
            this.lblRfcSocio.AutoSize = true;
            this.lblRfcSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRfcSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblRfcSocio.Location = new System.Drawing.Point(30, 145);
            this.lblRfcSocio.Name = "lblRfcSocio";
            this.lblRfcSocio.Size = new System.Drawing.Size(43, 18);
            this.lblRfcSocio.TabIndex = 59;
            this.lblRfcSocio.Text = "RFC:";
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(34, 183);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(144, 13);
            this.bunifuSeparator6.TabIndex = 60;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // txtTelefonoPSocio
            // 
            this.txtTelefonoPSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtTelefonoPSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefonoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefonoPSocio.Location = new System.Drawing.Point(364, 309);
            this.txtTelefonoPSocio.Name = "txtTelefonoPSocio";
            this.txtTelefonoPSocio.Size = new System.Drawing.Size(113, 19);
            this.txtTelefonoPSocio.TabIndex = 75;
            this.txtTelefonoPSocio.Text = "6641978732";
            this.txtTelefonoPSocio.TextChanged += new System.EventHandler(this.txtTelefonoPSocio_TextChanged);
            this.txtTelefonoPSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtTelefonoPSocio_Validating);
            this.txtTelefonoPSocio.Validated += new System.EventHandler(this.txtTelefonoPSocio_Validated);
            // 
            // lblTelefonoPSocio
            // 
            this.lblTelefonoPSocio.AutoSize = true;
            this.lblTelefonoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefonoPSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTelefonoPSocio.Location = new System.Drawing.Point(361, 286);
            this.lblTelefonoPSocio.Name = "lblTelefonoPSocio";
            this.lblTelefonoPSocio.Size = new System.Drawing.Size(120, 18);
            this.lblTelefonoPSocio.TabIndex = 73;
            this.lblTelefonoPSocio.Text = "Telefono princial:";
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(365, 324);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(112, 13);
            this.bunifuSeparator8.TabIndex = 74;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = false;
            // 
            // txtTelefono2Socio
            // 
            this.txtTelefono2Socio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtTelefono2Socio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefono2Socio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefono2Socio.Location = new System.Drawing.Point(507, 309);
            this.txtTelefono2Socio.Name = "txtTelefono2Socio";
            this.txtTelefono2Socio.Size = new System.Drawing.Size(112, 19);
            this.txtTelefono2Socio.TabIndex = 72;
            this.txtTelefono2Socio.Text = "5567";
            this.txtTelefono2Socio.TextChanged += new System.EventHandler(this.txtTelefono2Socio_TextChanged);
            this.txtTelefono2Socio.Validating += new System.ComponentModel.CancelEventHandler(this.txtTelefono2Socio_Validating);
            this.txtTelefono2Socio.Validated += new System.EventHandler(this.txtTelefono2Socio_Validated);
            // 
            // txtTelefono3Socio
            // 
            this.txtTelefono3Socio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtTelefono3Socio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefono3Socio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefono3Socio.Location = new System.Drawing.Point(34, 364);
            this.txtTelefono3Socio.Name = "txtTelefono3Socio";
            this.txtTelefono3Socio.Size = new System.Drawing.Size(112, 19);
            this.txtTelefono3Socio.TabIndex = 71;
            this.txtTelefono3Socio.TextChanged += new System.EventHandler(this.txtTelefono3Socio_TextChanged);
            this.txtTelefono3Socio.Validating += new System.ComponentModel.CancelEventHandler(this.txtTelefono3Socio_Validating);
            this.txtTelefono3Socio.Validated += new System.EventHandler(this.txtTelefono3Socio_Validated);
            // 
            // txtCorreoSocio
            // 
            this.txtCorreoSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtCorreoSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCorreoSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCorreoSocio.Location = new System.Drawing.Point(33, 309);
            this.txtCorreoSocio.Name = "txtCorreoSocio";
            this.txtCorreoSocio.Size = new System.Drawing.Size(301, 19);
            this.txtCorreoSocio.TabIndex = 70;
            this.txtCorreoSocio.Text = "santoskarla122308@gmail.com";
            this.txtCorreoSocio.TextChanged += new System.EventHandler(this.txtCorreoSocio_TextChanged);
            this.txtCorreoSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtCorreoSocio_Validating);
            this.txtCorreoSocio.Validated += new System.EventHandler(this.txtCorreoSocio_Validated);
            // 
            // lblTelefono3Socio
            // 
            this.lblTelefono3Socio.AutoSize = true;
            this.lblTelefono3Socio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefono3Socio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTelefono3Socio.Location = new System.Drawing.Point(30, 341);
            this.lblTelefono3Socio.Name = "lblTelefono3Socio";
            this.lblTelefono3Socio.Size = new System.Drawing.Size(82, 18);
            this.lblTelefono3Socio.TabIndex = 68;
            this.lblTelefono3Socio.Text = "Telefono 3:";
            // 
            // bunifuSeparator9
            // 
            this.bunifuSeparator9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator9.LineThickness = 1;
            this.bunifuSeparator9.Location = new System.Drawing.Point(34, 379);
            this.bunifuSeparator9.Name = "bunifuSeparator9";
            this.bunifuSeparator9.Size = new System.Drawing.Size(111, 13);
            this.bunifuSeparator9.TabIndex = 69;
            this.bunifuSeparator9.Transparency = 255;
            this.bunifuSeparator9.Vertical = false;
            // 
            // lblTelefono2Socio
            // 
            this.lblTelefono2Socio.AutoSize = true;
            this.lblTelefono2Socio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefono2Socio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTelefono2Socio.Location = new System.Drawing.Point(503, 286);
            this.lblTelefono2Socio.Name = "lblTelefono2Socio";
            this.lblTelefono2Socio.Size = new System.Drawing.Size(82, 18);
            this.lblTelefono2Socio.TabIndex = 66;
            this.lblTelefono2Socio.Text = "Telefono 2:";
            // 
            // bunifuSeparator10
            // 
            this.bunifuSeparator10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator10.LineThickness = 1;
            this.bunifuSeparator10.Location = new System.Drawing.Point(507, 324);
            this.bunifuSeparator10.Name = "bunifuSeparator10";
            this.bunifuSeparator10.Size = new System.Drawing.Size(112, 13);
            this.bunifuSeparator10.TabIndex = 67;
            this.bunifuSeparator10.Transparency = 255;
            this.bunifuSeparator10.Vertical = false;
            // 
            // lblCorreoSocio
            // 
            this.lblCorreoSocio.AutoSize = true;
            this.lblCorreoSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorreoSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCorreoSocio.Location = new System.Drawing.Point(30, 286);
            this.lblCorreoSocio.Name = "lblCorreoSocio";
            this.lblCorreoSocio.Size = new System.Drawing.Size(136, 18);
            this.lblCorreoSocio.TabIndex = 64;
            this.lblCorreoSocio.Text = "Correo electronico:";
            // 
            // bunifuSeparator11
            // 
            this.bunifuSeparator11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator11.LineThickness = 1;
            this.bunifuSeparator11.Location = new System.Drawing.Point(34, 324);
            this.bunifuSeparator11.Name = "bunifuSeparator11";
            this.bunifuSeparator11.Size = new System.Drawing.Size(300, 13);
            this.bunifuSeparator11.TabIndex = 65;
            this.bunifuSeparator11.Transparency = 255;
            this.bunifuSeparator11.Vertical = false;
            // 
            // lblTipoPSocio
            // 
            this.lblTipoPSocio.AutoSize = true;
            this.lblTipoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoPSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTipoPSocio.Location = new System.Drawing.Point(198, 145);
            this.lblTipoPSocio.Name = "lblTipoPSocio";
            this.lblTipoPSocio.Size = new System.Drawing.Size(119, 18);
            this.lblTipoPSocio.TabIndex = 76;
            this.lblTipoPSocio.Text = "Tipo de persona:";
            // 
            // cbTipoPSocio
            // 
            this.cbTipoPSocio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbTipoPSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbTipoPSocio.FormattingEnabled = true;
            this.cbTipoPSocio.Items.AddRange(new object[] {
            "FISICA",
            "MORAL"});
            this.cbTipoPSocio.Location = new System.Drawing.Point(201, 166);
            this.cbTipoPSocio.Name = "cbTipoPSocio";
            this.cbTipoPSocio.Size = new System.Drawing.Size(126, 26);
            this.cbTipoPSocio.TabIndex = 77;
            this.cbTipoPSocio.Text = "- Seleccione -";
            // 
            // cbEstadoSocio
            // 
            this.cbEstadoSocio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbEstadoSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbEstadoSocio.FormattingEnabled = true;
            this.cbEstadoSocio.Location = new System.Drawing.Point(529, 166);
            this.cbEstadoSocio.Name = "cbEstadoSocio";
            this.cbEstadoSocio.Size = new System.Drawing.Size(126, 26);
            this.cbEstadoSocio.TabIndex = 79;
            this.cbEstadoSocio.Text = "- Seleccione -";
            // 
            // lblEstadoSocio
            // 
            this.lblEstadoSocio.AutoSize = true;
            this.lblEstadoSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstadoSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblEstadoSocio.Location = new System.Drawing.Point(526, 145);
            this.lblEstadoSocio.Name = "lblEstadoSocio";
            this.lblEstadoSocio.Size = new System.Drawing.Size(126, 18);
            this.lblEstadoSocio.TabIndex = 78;
            this.lblEstadoSocio.Text = "EstatusBLL del socio:";
            // 
            // dpFechaNSocio
            // 
            this.dpFechaNSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.dpFechaNSocio.BorderRadius = 0;
            this.dpFechaNSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpFechaNSocio.ForeColor = System.Drawing.Color.White;
            this.dpFechaNSocio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dpFechaNSocio.FormatCustom = null;
            this.dpFechaNSocio.Location = new System.Drawing.Point(348, 164);
            this.dpFechaNSocio.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dpFechaNSocio.Name = "dpFechaNSocio";
            this.dpFechaNSocio.Size = new System.Drawing.Size(161, 30);
            this.dpFechaNSocio.TabIndex = 80;
            this.dpFechaNSocio.Value = new System.DateTime(2023, 4, 30, 22, 40, 42, 977);
            // 
            // lblFechaNSocio
            // 
            this.lblFechaNSocio.AutoSize = true;
            this.lblFechaNSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFechaNSocio.Location = new System.Drawing.Point(345, 145);
            this.lblFechaNSocio.Name = "lblFechaNSocio";
            this.lblFechaNSocio.Size = new System.Drawing.Size(149, 18);
            this.lblFechaNSocio.TabIndex = 81;
            this.lblFechaNSocio.Text = "Fecha de nacimiento:";
            // 
            // txtNoExtSocio
            // 
            this.txtNoExtSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNoExtSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoExtSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNoExtSocio.Location = new System.Drawing.Point(252, 443);
            this.txtNoExtSocio.Name = "txtNoExtSocio";
            this.txtNoExtSocio.Size = new System.Drawing.Size(88, 19);
            this.txtNoExtSocio.TabIndex = 95;
            this.txtNoExtSocio.Text = "1223";
            this.txtNoExtSocio.TextChanged += new System.EventHandler(this.txtNoExtSocio_TextChanged);
            this.txtNoExtSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtNoExtSocio_Validating);
            this.txtNoExtSocio.Validated += new System.EventHandler(this.txtNoExtSocio_Validated);
            // 
            // lblNoExtSocio
            // 
            this.lblNoExtSocio.AutoSize = true;
            this.lblNoExtSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoExtSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNoExtSocio.Location = new System.Drawing.Point(249, 420);
            this.lblNoExtSocio.Name = "lblNoExtSocio";
            this.lblNoExtSocio.Size = new System.Drawing.Size(91, 18);
            this.lblNoExtSocio.TabIndex = 93;
            this.lblNoExtSocio.Text = "No. Exterior:";
            // 
            // bunifuSeparator12
            // 
            this.bunifuSeparator12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator12.LineThickness = 1;
            this.bunifuSeparator12.Location = new System.Drawing.Point(253, 458);
            this.bunifuSeparator12.Name = "bunifuSeparator12";
            this.bunifuSeparator12.Size = new System.Drawing.Size(87, 13);
            this.bunifuSeparator12.TabIndex = 94;
            this.bunifuSeparator12.Transparency = 255;
            this.bunifuSeparator12.Vertical = false;
            // 
            // txtNoIntSocio
            // 
            this.txtNoIntSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNoIntSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNoIntSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNoIntSocio.Location = new System.Drawing.Point(366, 443);
            this.txtNoIntSocio.Name = "txtNoIntSocio";
            this.txtNoIntSocio.Size = new System.Drawing.Size(78, 19);
            this.txtNoIntSocio.TabIndex = 92;
            this.txtNoIntSocio.TextChanged += new System.EventHandler(this.txtNoIntSocio_TextChanged);
            this.txtNoIntSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtNoIntSocio_Validating);
            this.txtNoIntSocio.Validated += new System.EventHandler(this.txtNoIntSocio_Validated);
            // 
            // txtColoniaSocio
            // 
            this.txtColoniaSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtColoniaSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColoniaSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtColoniaSocio.Location = new System.Drawing.Point(471, 443);
            this.txtColoniaSocio.Name = "txtColoniaSocio";
            this.txtColoniaSocio.Size = new System.Drawing.Size(192, 19);
            this.txtColoniaSocio.TabIndex = 91;
            this.txtColoniaSocio.Text = "Vista del Valle";
            this.txtColoniaSocio.TextChanged += new System.EventHandler(this.txtColoniaSocio_TextChanged);
            this.txtColoniaSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtColoniaSocio_Validating);
            this.txtColoniaSocio.Validated += new System.EventHandler(this.txtColoniaSocio_Validated);
            // 
            // txtCalleSocio
            // 
            this.txtCalleSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtCalleSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCalleSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCalleSocio.Location = new System.Drawing.Point(33, 443);
            this.txtCalleSocio.Name = "txtCalleSocio";
            this.txtCalleSocio.Size = new System.Drawing.Size(192, 19);
            this.txtCalleSocio.TabIndex = 90;
            this.txtCalleSocio.Text = "valle encantado";
            this.txtCalleSocio.TextChanged += new System.EventHandler(this.txtCalleSocio_TextChanged);
            this.txtCalleSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtCalleSocio_Validating);
            this.txtCalleSocio.Validated += new System.EventHandler(this.txtCalleSocio_Validated);
            // 
            // lblColoniaSocio
            // 
            this.lblColoniaSocio.AutoSize = true;
            this.lblColoniaSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColoniaSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblColoniaSocio.Location = new System.Drawing.Point(467, 420);
            this.lblColoniaSocio.Name = "lblColoniaSocio";
            this.lblColoniaSocio.Size = new System.Drawing.Size(63, 18);
            this.lblColoniaSocio.TabIndex = 88;
            this.lblColoniaSocio.Text = "Colonia:";
            // 
            // bunifuSeparator13
            // 
            this.bunifuSeparator13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator13.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator13.LineThickness = 1;
            this.bunifuSeparator13.Location = new System.Drawing.Point(471, 458);
            this.bunifuSeparator13.Name = "bunifuSeparator13";
            this.bunifuSeparator13.Size = new System.Drawing.Size(191, 13);
            this.bunifuSeparator13.TabIndex = 89;
            this.bunifuSeparator13.Transparency = 255;
            this.bunifuSeparator13.Vertical = false;
            // 
            // lblNoIntSocio
            // 
            this.lblNoIntSocio.AutoSize = true;
            this.lblNoIntSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoIntSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNoIntSocio.Location = new System.Drawing.Point(362, 420);
            this.lblNoIntSocio.Name = "lblNoIntSocio";
            this.lblNoIntSocio.Size = new System.Drawing.Size(85, 18);
            this.lblNoIntSocio.TabIndex = 86;
            this.lblNoIntSocio.Text = "No. Interior:";
            // 
            // bunifuSeparator14
            // 
            this.bunifuSeparator14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator14.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator14.LineThickness = 1;
            this.bunifuSeparator14.Location = new System.Drawing.Point(366, 458);
            this.bunifuSeparator14.Name = "bunifuSeparator14";
            this.bunifuSeparator14.Size = new System.Drawing.Size(77, 13);
            this.bunifuSeparator14.TabIndex = 87;
            this.bunifuSeparator14.Transparency = 255;
            this.bunifuSeparator14.Vertical = false;
            // 
            // lblCalleSocio
            // 
            this.lblCalleSocio.AutoSize = true;
            this.lblCalleSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalleSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCalleSocio.Location = new System.Drawing.Point(30, 420);
            this.lblCalleSocio.Name = "lblCalleSocio";
            this.lblCalleSocio.Size = new System.Drawing.Size(45, 18);
            this.lblCalleSocio.TabIndex = 84;
            this.lblCalleSocio.Text = "Calle:";
            // 
            // bunifuSeparator15
            // 
            this.bunifuSeparator15.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator15.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator15.LineThickness = 1;
            this.bunifuSeparator15.Location = new System.Drawing.Point(34, 458);
            this.bunifuSeparator15.Name = "bunifuSeparator15";
            this.bunifuSeparator15.Size = new System.Drawing.Size(191, 13);
            this.bunifuSeparator15.TabIndex = 85;
            this.bunifuSeparator15.Transparency = 255;
            this.bunifuSeparator15.Vertical = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.IndianRed;
            this.label21.Location = new System.Drawing.Point(243, 394);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(205, 20);
            this.label21.TabIndex = 83;
            this.label21.Text = "DIRECCION PARTICULAR";
            // 
            // bunifuSeparator16
            // 
            this.bunifuSeparator16.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator16.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator16.LineThickness = 4;
            this.bunifuSeparator16.Location = new System.Drawing.Point(28, 399);
            this.bunifuSeparator16.Name = "bunifuSeparator16";
            this.bunifuSeparator16.Size = new System.Drawing.Size(638, 10);
            this.bunifuSeparator16.TabIndex = 82;
            this.bunifuSeparator16.Transparency = 255;
            this.bunifuSeparator16.Vertical = false;
            // 
            // txtCpSocio
            // 
            this.txtCpSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtCpSocio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCpSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCpSocio.Location = new System.Drawing.Point(35, 497);
            this.txtCpSocio.Name = "txtCpSocio";
            this.txtCpSocio.Size = new System.Drawing.Size(59, 19);
            this.txtCpSocio.TabIndex = 105;
            this.txtCpSocio.Text = "22330";
            this.txtCpSocio.TextChanged += new System.EventHandler(this.txtCpSocio_TextChanged);
            this.txtCpSocio.Validating += new System.ComponentModel.CancelEventHandler(this.txtCpSocio_Validating);
            this.txtCpSocio.Validated += new System.EventHandler(this.txtCpSocio_Validated);
            // 
            // lblCpSocio
            // 
            this.lblCpSocio.AutoSize = true;
            this.lblCpSocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpSocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCpSocio.Location = new System.Drawing.Point(30, 474);
            this.lblCpSocio.Name = "lblCpSocio";
            this.lblCpSocio.Size = new System.Drawing.Size(41, 18);
            this.lblCpSocio.TabIndex = 103;
            this.lblCpSocio.Text = "C.P.:";
            // 
            // bunifuSeparator19
            // 
            this.bunifuSeparator19.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator19.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator19.LineThickness = 1;
            this.bunifuSeparator19.Location = new System.Drawing.Point(34, 512);
            this.bunifuSeparator19.Name = "bunifuSeparator19";
            this.bunifuSeparator19.Size = new System.Drawing.Size(58, 13);
            this.bunifuSeparator19.TabIndex = 104;
            this.bunifuSeparator19.Transparency = 255;
            this.bunifuSeparator19.Vertical = false;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator7.LineThickness = 4;
            this.bunifuSeparator7.Location = new System.Drawing.Point(28, 262);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(638, 10);
            this.bunifuSeparator7.TabIndex = 62;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.IndianRed;
            this.label9.Location = new System.Drawing.Point(254, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 20);
            this.label9.TabIndex = 63;
            this.label9.Text = "DATOS DE CONTACTO";
            // 
            // lblFechaISocio
            // 
            this.lblFechaISocio.AutoSize = true;
            this.lblFechaISocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaISocio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFechaISocio.Location = new System.Drawing.Point(30, 204);
            this.lblFechaISocio.Name = "lblFechaISocio";
            this.lblFechaISocio.Size = new System.Drawing.Size(126, 18);
            this.lblFechaISocio.TabIndex = 110;
            this.lblFechaISocio.Text = "Fecha de ingreso:";
            // 
            // dpFechaISocio
            // 
            this.dpFechaISocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(175)))), ((int)(((byte)(107)))));
            this.dpFechaISocio.BorderRadius = 0;
            this.dpFechaISocio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpFechaISocio.ForeColor = System.Drawing.Color.White;
            this.dpFechaISocio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dpFechaISocio.FormatCustom = null;
            this.dpFechaISocio.Location = new System.Drawing.Point(33, 223);
            this.dpFechaISocio.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dpFechaISocio.Name = "dpFechaISocio";
            this.dpFechaISocio.Size = new System.Drawing.Size(161, 30);
            this.dpFechaISocio.TabIndex = 109;
            this.dpFechaISocio.Value = new System.DateTime(2023, 4, 30, 22, 40, 42, 977);
            // 
            // lblAgregar
            // 
            this.lblAgregar.AutoSize = true;
            this.lblAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgregar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblAgregar.Location = new System.Drawing.Point(12, 50);
            this.lblAgregar.Name = "lblAgregar";
            this.lblAgregar.Size = new System.Drawing.Size(59, 17);
            this.lblAgregar.TabIndex = 112;
            this.lblAgregar.Text = "Agregar";
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.cmdAgregar.Controls.Add(this.pbAgregar);
            this.cmdAgregar.Controls.Add(this.lblAgregar);
            this.cmdAgregar.Location = new System.Drawing.Point(300, 552);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(81, 72);
            this.cmdAgregar.TabIndex = 113;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // pbAgregar
            // 
            this.pbAgregar.Image = ((System.Drawing.Image)(resources.GetObject("pbAgregar.Image")));
            this.pbAgregar.Location = new System.Drawing.Point(23, 11);
            this.pbAgregar.Name = "pbAgregar";
            this.pbAgregar.Size = new System.Drawing.Size(38, 39);
            this.pbAgregar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbAgregar.TabIndex = 111;
            this.pbAgregar.TabStop = false;
            // 
            // rdcmdAgregar
            // 
            this.rdcmdAgregar.ElipseRadius = 20;
            this.rdcmdAgregar.TargetControl = this.cmdAgregar;
            // 
            // cbCiudad
            // 
            this.cbCiudad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cbCiudad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbCiudad.FormattingEnabled = true;
            this.cbCiudad.Location = new System.Drawing.Point(113, 495);
            this.cbCiudad.Name = "cbCiudad";
            this.cbCiudad.Size = new System.Drawing.Size(177, 26);
            this.cbCiudad.TabIndex = 188;
            this.cbCiudad.Text = "- SELECCIONE CIUDAD-";
            this.cbCiudad.SelectedIndexChanged += new System.EventHandler(this.cbCiudad_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(535, 471);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 21);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 197;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(364, 471);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(21, 21);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 196;
            this.pictureBox4.TabStop = false;
            // 
            // txtPais
            // 
            this.txtPais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtPais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPais.Location = new System.Drawing.Point(498, 497);
            this.txtPais.Name = "txtPais";
            this.txtPais.ReadOnly = true;
            this.txtPais.Size = new System.Drawing.Size(162, 19);
            this.txtPais.TabIndex = 190;
            this.txtPais.Text = "México";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label25.Location = new System.Drawing.Point(495, 474);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 18);
            this.label25.TabIndex = 193;
            this.label25.Text = "Pais:";
            // 
            // bunifuSeparator20
            // 
            this.bunifuSeparator20.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator20.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator20.LineThickness = 1;
            this.bunifuSeparator20.Location = new System.Drawing.Point(499, 512);
            this.bunifuSeparator20.Name = "bunifuSeparator20";
            this.bunifuSeparator20.Size = new System.Drawing.Size(161, 13);
            this.bunifuSeparator20.TabIndex = 194;
            this.bunifuSeparator20.Transparency = 255;
            this.bunifuSeparator20.Vertical = false;
            // 
            // txtEstado
            // 
            this.txtEstado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEstado.Location = new System.Drawing.Point(309, 497);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.ReadOnly = true;
            this.txtEstado.Size = new System.Drawing.Size(168, 19);
            this.txtEstado.TabIndex = 189;
            this.txtEstado.Text = "Baja California";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label23.Location = new System.Drawing.Point(306, 474);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 18);
            this.label23.TabIndex = 191;
            this.label23.Text = "Estado:";
            // 
            // bunifuSeparator18
            // 
            this.bunifuSeparator18.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator18.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator18.LineThickness = 1;
            this.bunifuSeparator18.Location = new System.Drawing.Point(310, 512);
            this.bunifuSeparator18.Name = "bunifuSeparator18";
            this.bunifuSeparator18.Size = new System.Drawing.Size(167, 13);
            this.bunifuSeparator18.TabIndex = 192;
            this.bunifuSeparator18.Transparency = 255;
            this.bunifuSeparator18.Vertical = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label22.Location = new System.Drawing.Point(110, 474);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 18);
            this.label22.TabIndex = 195;
            this.label22.Text = "Ciudad:";
            // 
            // pnModificar
            // 
            this.pnModificar.Controls.Add(this.cmdBorrar);
            this.pnModificar.Controls.Add(this.cmdModificar);
            this.pnModificar.Location = new System.Drawing.Point(216, 541);
            this.pnModificar.Name = "pnModificar";
            this.pnModificar.Size = new System.Drawing.Size(242, 96);
            this.pnModificar.TabIndex = 198;
            this.pnModificar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // cmdBorrar
            // 
            this.cmdBorrar.BackColor = System.Drawing.Color.MistyRose;
            this.cmdBorrar.Controls.Add(this.pbBorrar);
            this.cmdBorrar.Controls.Add(this.lblBorrar);
            this.cmdBorrar.Location = new System.Drawing.Point(146, 12);
            this.cmdBorrar.Name = "cmdBorrar";
            this.cmdBorrar.Size = new System.Drawing.Size(81, 72);
            this.cmdBorrar.TabIndex = 189;
            this.cmdBorrar.Click += new System.EventHandler(this.cmdBorrar_Click);
            // 
            // pbBorrar
            // 
            this.pbBorrar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.borrar__1_;
            this.pbBorrar.Location = new System.Drawing.Point(18, 6);
            this.pbBorrar.Name = "pbBorrar";
            this.pbBorrar.Size = new System.Drawing.Size(44, 41);
            this.pbBorrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBorrar.TabIndex = 111;
            this.pbBorrar.TabStop = false;
            this.pbBorrar.Click += new System.EventHandler(this.cmdBorrar_Click);
            // 
            // lblBorrar
            // 
            this.lblBorrar.AutoSize = true;
            this.lblBorrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBorrar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblBorrar.Location = new System.Drawing.Point(13, 45);
            this.lblBorrar.Name = "lblBorrar";
            this.lblBorrar.Size = new System.Drawing.Size(58, 17);
            this.lblBorrar.TabIndex = 0;
            this.lblBorrar.Text = "Eliminar";
            this.lblBorrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // cmdModificar
            // 
            this.cmdModificar.BackColor = System.Drawing.Color.MistyRose;
            this.cmdModificar.Controls.Add(this.pbModificar);
            this.cmdModificar.Controls.Add(this.lblModificar);
            this.cmdModificar.Location = new System.Drawing.Point(17, 12);
            this.cmdModificar.Name = "cmdModificar";
            this.cmdModificar.Size = new System.Drawing.Size(81, 72);
            this.cmdModificar.TabIndex = 188;
            this.cmdModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // pbModificar
            // 
            this.pbModificar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.editar__1_;
            this.pbModificar.Location = new System.Drawing.Point(22, 7);
            this.pbModificar.Name = "pbModificar";
            this.pbModificar.Size = new System.Drawing.Size(38, 39);
            this.pbModificar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbModificar.TabIndex = 111;
            this.pbModificar.TabStop = false;
            this.pbModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // lblModificar
            // 
            this.lblModificar.AutoSize = true;
            this.lblModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModificar.ForeColor = System.Drawing.Color.IndianRed;
            this.lblModificar.Location = new System.Drawing.Point(9, 44);
            this.lblModificar.Name = "lblModificar";
            this.lblModificar.Size = new System.Drawing.Size(65, 17);
            this.lblModificar.TabIndex = 0;
            this.lblModificar.Text = "Modificar";
            this.lblModificar.Click += new System.EventHandler(this.cmdModificar_Click);
            // 
            // error1
            // 
            this.error1.ContainerControl = this;
            // 
            // error2
            // 
            this.error2.ContainerControl = this;
            // 
            // frmEdit_Socios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.ClientSize = new System.Drawing.Size(696, 649);
            this.Controls.Add(this.pnModificar);
            this.Controls.Add(this.cbCiudad);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.txtPais);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.bunifuSeparator20);
            this.Controls.Add(this.txtEstado);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.bunifuSeparator18);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmdAgregar);
            this.Controls.Add(this.lblFechaISocio);
            this.Controls.Add(this.dpFechaISocio);
            this.Controls.Add(this.txtCpSocio);
            this.Controls.Add(this.lblCpSocio);
            this.Controls.Add(this.bunifuSeparator19);
            this.Controls.Add(this.txtNoExtSocio);
            this.Controls.Add(this.lblNoExtSocio);
            this.Controls.Add(this.bunifuSeparator12);
            this.Controls.Add(this.txtNoIntSocio);
            this.Controls.Add(this.txtColoniaSocio);
            this.Controls.Add(this.txtCalleSocio);
            this.Controls.Add(this.lblColoniaSocio);
            this.Controls.Add(this.bunifuSeparator13);
            this.Controls.Add(this.lblNoIntSocio);
            this.Controls.Add(this.bunifuSeparator14);
            this.Controls.Add(this.lblCalleSocio);
            this.Controls.Add(this.bunifuSeparator15);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.bunifuSeparator16);
            this.Controls.Add(this.lblFechaNSocio);
            this.Controls.Add(this.dpFechaNSocio);
            this.Controls.Add(this.cbEstadoSocio);
            this.Controls.Add(this.lblEstadoSocio);
            this.Controls.Add(this.cbTipoPSocio);
            this.Controls.Add(this.lblTipoPSocio);
            this.Controls.Add(this.txtTelefonoPSocio);
            this.Controls.Add(this.lblTelefonoPSocio);
            this.Controls.Add(this.bunifuSeparator8);
            this.Controls.Add(this.txtTelefono2Socio);
            this.Controls.Add(this.txtTelefono3Socio);
            this.Controls.Add(this.txtCorreoSocio);
            this.Controls.Add(this.lblTelefono3Socio);
            this.Controls.Add(this.bunifuSeparator9);
            this.Controls.Add(this.lblTelefono2Socio);
            this.Controls.Add(this.bunifuSeparator10);
            this.Controls.Add(this.lblCorreoSocio);
            this.Controls.Add(this.bunifuSeparator11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.bunifuSeparator7);
            this.Controls.Add(this.txtRfcSocio);
            this.Controls.Add(this.lblRfcSocio);
            this.Controls.Add(this.bunifuSeparator6);
            this.Controls.Add(this.txtSocioID);
            this.Controls.Add(this.lblSocioID);
            this.Controls.Add(this.bunifuSeparator5);
            this.Controls.Add(this.txtApellidoPSocio);
            this.Controls.Add(this.txtApellidoMSocio);
            this.Controls.Add(this.txtNombreSocio);
            this.Controls.Add(this.lblApellidoMSocio);
            this.Controls.Add(this.bunifuSeparator4);
            this.Controls.Add(this.lblApellidoPSocio);
            this.Controls.Add(this.bunifuSeparator3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.lblNombreSocio);
            this.Controls.Add(this.encabezado);
            this.Controls.Add(this.bunifuSeparator2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmEdit_Socios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSocios";
            this.Load += new System.EventHandler(this.frmEdit_Socios_Load);
            this.encabezado.ResumeLayout(false);
            this.encabezado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdCerrar)).EndInit();
            this.cmdAgregar.ResumeLayout(false);
            this.cmdAgregar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAgregar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pnModificar.ResumeLayout(false);
            this.cmdBorrar.ResumeLayout(false);
            this.cmdBorrar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBorrar)).EndInit();
            this.cmdModificar.ResumeLayout(false);
            this.cmdModificar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbModificar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public  ns1.BunifuImageButton cmdCerrar;
        public  ns1.BunifuElipse rdSocios;
        public  System.Windows.Forms.Panel encabezado;
        public  System.Windows.Forms.PictureBox pbLogo;
        public  ns1.BunifuSeparator bunifuSeparator2;
        public  System.Windows.Forms.Label lblNombreSocio;
        public System.Windows.Forms.Label lblTitle;
        public  System.Windows.Forms.Label label4;
        public  ns1.BunifuSeparator bunifuSeparator1;
        public  System.Windows.Forms.Label lblApellidoMSocio;
        public  ns1.BunifuSeparator bunifuSeparator4;
        public  System.Windows.Forms.Label lblApellidoPSocio;
        public  ns1.BunifuSeparator bunifuSeparator3;
        public  System.Windows.Forms.ComboBox cbEstadoSocio;
        public  System.Windows.Forms.Label lblEstadoSocio;
        public  System.Windows.Forms.ComboBox cbTipoPSocio;
        public  System.Windows.Forms.Label lblTipoPSocio;
        public  System.Windows.Forms.TextBox txtTelefonoPSocio;
        public  System.Windows.Forms.Label lblTelefonoPSocio;
        public  ns1.BunifuSeparator bunifuSeparator8;
        public  System.Windows.Forms.TextBox txtTelefono2Socio;
        public  System.Windows.Forms.TextBox txtTelefono3Socio;
        public  System.Windows.Forms.TextBox txtCorreoSocio;
        public  System.Windows.Forms.Label lblTelefono3Socio;
        public  ns1.BunifuSeparator bunifuSeparator9;
        public  System.Windows.Forms.Label lblTelefono2Socio;
        public  ns1.BunifuSeparator bunifuSeparator10;
        public  System.Windows.Forms.Label lblCorreoSocio;
        public  ns1.BunifuSeparator bunifuSeparator11;
        public  System.Windows.Forms.TextBox txtRfcSocio;
        public  System.Windows.Forms.Label lblRfcSocio;
        public  ns1.BunifuSeparator bunifuSeparator6;
        public  System.Windows.Forms.TextBox txtSocioID;
        public  System.Windows.Forms.Label lblSocioID;
        public  ns1.BunifuSeparator bunifuSeparator5;
        public  System.Windows.Forms.TextBox txtApellidoPSocio;
        public  System.Windows.Forms.TextBox txtApellidoMSocio;
        public  System.Windows.Forms.TextBox txtNombreSocio;
        public  ns1.BunifuDatepicker dpFechaNSocio;
        public  System.Windows.Forms.Label lblFechaNSocio;
        public  System.Windows.Forms.TextBox txtCpSocio;
        public  System.Windows.Forms.Label lblCpSocio;
        public  ns1.BunifuSeparator bunifuSeparator19;
        public  System.Windows.Forms.TextBox txtNoExtSocio;
        public  System.Windows.Forms.Label lblNoExtSocio;
        public  ns1.BunifuSeparator bunifuSeparator12;
        public  System.Windows.Forms.TextBox txtNoIntSocio;
        public  System.Windows.Forms.TextBox txtColoniaSocio;
        public  System.Windows.Forms.TextBox txtCalleSocio;
        public  System.Windows.Forms.Label lblColoniaSocio;
        public  ns1.BunifuSeparator bunifuSeparator13;
        public  System.Windows.Forms.Label lblNoIntSocio;
        public  ns1.BunifuSeparator bunifuSeparator14;
        public  System.Windows.Forms.Label lblCalleSocio;
        public  ns1.BunifuSeparator bunifuSeparator15;
        public  System.Windows.Forms.Label label21;
        public  ns1.BunifuSeparator bunifuSeparator16;
        public  System.Windows.Forms.Label lblFechaISocio;
        public  ns1.BunifuDatepicker dpFechaISocio;
        public  System.Windows.Forms.Label label9;
        public  ns1.BunifuSeparator bunifuSeparator7;
        public  System.Windows.Forms.Panel cmdAgregar;
        public  System.Windows.Forms.PictureBox pbAgregar;
        public  System.Windows.Forms.Label lblAgregar;
        public  ns1.BunifuElipse rdcmdAgregar;
        public System.Windows.Forms.ComboBox cbCiudad;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.TextBox txtPais;
        public System.Windows.Forms.Label label25;
        public ns1.BunifuSeparator bunifuSeparator20;
        public System.Windows.Forms.TextBox txtEstado;
        public System.Windows.Forms.Label label23;
        public ns1.BunifuSeparator bunifuSeparator18;
        public System.Windows.Forms.Label label22;
        public  System.Windows.Forms.Panel pnModificar;
        public System.Windows.Forms.Panel cmdBorrar;
        public System.Windows.Forms.PictureBox pbBorrar;
        public System.Windows.Forms.Label lblBorrar;
        public System.Windows.Forms.Panel cmdModificar;
        public System.Windows.Forms.PictureBox pbModificar;
        public System.Windows.Forms.Label lblModificar;
        private System.Windows.Forms.ErrorProvider error1;
        private System.Windows.Forms.ErrorProvider error2;
    }
}