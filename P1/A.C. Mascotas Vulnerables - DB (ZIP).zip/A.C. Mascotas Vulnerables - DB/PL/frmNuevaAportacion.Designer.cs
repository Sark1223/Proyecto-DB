﻿namespace A.C.Mascotas_Vulnerables___DB.PL
{
    partial class frmNuevaAportacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNuevaAportacion));
            this.rdNuevaAportacion = new ns1.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCerrar = new ns1.BunifuImageButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuImageButton1 = new ns1.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnSocio = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.cmdBuscar = new ns1.BunifuThinButton2();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.lblAMaterno = new ns1.BunifuCustomLabel();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.lblAPaterno = new ns1.BunifuCustomLabel();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.lblNombre = new ns1.BunifuCustomLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnMonto = new System.Windows.Forms.Panel();
            this.txtImporte = new System.Windows.Forms.TextBox();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMtoEscrito = new ns1.BunifuMetroTextbox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.cmdGuardar = new ns1.BunifuThinButton2();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnAgregarRecibo = new ns1.BunifuThinButton2();
            this.label10 = new System.Windows.Forms.Label();
            this.dtFecha = new ns1.BunifuDatepicker();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.pnFirmas = new System.Windows.Forms.Panel();
            this.pnEstatus = new System.Windows.Forms.Panel();
            this.cmdAgregarEstatus = new System.Windows.Forms.PictureBox();
            this.lblEstatus = new System.Windows.Forms.Label();
            this.cbEstatus = new System.Windows.Forms.ComboBox();
            this.lblEncargado2 = new ns1.BunifuCustomLabel();
            this.txtEncargado1 = new ns1.BunifuCustomLabel();
            this.cbEncargado2 = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.rdSocio = new ns1.BunifuElipse(this.components);
            this.rdMonto = new ns1.BunifuElipse(this.components);
            this.rdFirmas = new ns1.BunifuElipse(this.components);
            this.cbPeriodo = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lblPeriodo = new ns1.BunifuCustomLabel();
            this.error1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtFolio = new System.Windows.Forms.TextBox();
            this.bunifuSeparator6 = new ns1.BunifuSeparator();
            this.imprimirRec = new System.Drawing.Printing.PrintDocument();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.pnSocio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            this.pnMonto.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnFirmas.SuspendLayout();
            this.pnEstatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmdAgregarEstatus)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).BeginInit();
            this.SuspendLayout();
            // 
            // rdNuevaAportacion
            // 
            this.rdNuevaAportacion.ElipseRadius = 35;
            this.rdNuevaAportacion.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(175)))), ((int)(((byte)(107)))));
            this.panel1.Controls.Add(this.btnCerrar);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(796, 43);
            this.panel1.TabIndex = 10;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.Equis;
            this.btnCerrar.ImageActive = null;
            this.btnCerrar.Location = new System.Drawing.Point(746, 7);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(38, 25);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCerrar.TabIndex = 38;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Zoom = 10;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.perro;
            this.pictureBox1.Location = new System.Drawing.Point(13, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.Equis;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(828, 3);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(33, 35);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 0;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.cmdCerrar);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Datos del Socio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(110, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nombre(s):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(258, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Apellido Paterno:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(415, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Apellido Materno:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.Control;
            this.lblTitle.Location = new System.Drawing.Point(20, 109);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(121, 111);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Datos\r\ndel\r\nRecibo";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(405, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Fecha:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(62, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Importe$:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(245, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Importe en Letra:";
            // 
            // pnSocio
            // 
            this.pnSocio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.pnSocio.Controls.Add(this.pictureBox6);
            this.pnSocio.Controls.Add(this.pictureBox5);
            this.pnSocio.Controls.Add(this.pictureBox4);
            this.pnSocio.Controls.Add(this.pictureBox3);
            this.pnSocio.Controls.Add(this.cmdBuscar);
            this.pnSocio.Controls.Add(this.bunifuSeparator4);
            this.pnSocio.Controls.Add(this.lblAMaterno);
            this.pnSocio.Controls.Add(this.bunifuSeparator3);
            this.pnSocio.Controls.Add(this.lblAPaterno);
            this.pnSocio.Controls.Add(this.bunifuSeparator2);
            this.pnSocio.Controls.Add(this.lblNombre);
            this.pnSocio.Controls.Add(this.panel2);
            this.pnSocio.Controls.Add(this.label2);
            this.pnSocio.Controls.Add(this.label3);
            this.pnSocio.Controls.Add(this.label4);
            this.pnSocio.Location = new System.Drawing.Point(28, 137);
            this.pnSocio.Name = "pnSocio";
            this.pnSocio.Size = new System.Drawing.Size(576, 154);
            this.pnSocio.TabIndex = 24;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(542, 59);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(28, 21);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 40;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(381, 59);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(28, 21);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 39;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(198, 58);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(28, 21);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 38;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(15, 46);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(69, 65);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            // 
            // cmdBuscar
            // 
            this.cmdBuscar.ActiveBorderThickness = 1;
            this.cmdBuscar.ActiveCornerRadius = 20;
            this.cmdBuscar.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdBuscar.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.cmdBuscar.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdBuscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.cmdBuscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cmdBuscar.BackgroundImage")));
            this.cmdBuscar.ButtonText = "Buscar";
            this.cmdBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdBuscar.ForeColor = System.Drawing.Color.SeaGreen;
            this.cmdBuscar.IdleBorderThickness = 1;
            this.cmdBuscar.IdleCornerRadius = 20;
            this.cmdBuscar.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.cmdBuscar.IdleForecolor = System.Drawing.Color.White;
            this.cmdBuscar.IdleLineColor = System.Drawing.Color.Black;
            this.cmdBuscar.Location = new System.Drawing.Point(15, 112);
            this.cmdBuscar.Margin = new System.Windows.Forms.Padding(5);
            this.cmdBuscar.Name = "cmdBuscar";
            this.cmdBuscar.Size = new System.Drawing.Size(69, 37);
            this.cmdBuscar.TabIndex = 9;
            this.cmdBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdBuscar.Click += new System.EventHandler(this.BuscarSOcio);
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(419, 116);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(128, 13);
            this.bunifuSeparator4.TabIndex = 0;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // lblAMaterno
            // 
            this.lblAMaterno.AutoSize = true;
            this.lblAMaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAMaterno.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAMaterno.Location = new System.Drawing.Point(415, 93);
            this.lblAMaterno.Name = "lblAMaterno";
            this.lblAMaterno.Size = new System.Drawing.Size(54, 20);
            this.lblAMaterno.TabIndex = 1;
            this.lblAMaterno.Text = "Rivera";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(262, 116);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(125, 13);
            this.bunifuSeparator3.TabIndex = 3;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // lblAPaterno
            // 
            this.lblAPaterno.AutoSize = true;
            this.lblAPaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAPaterno.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAPaterno.Location = new System.Drawing.Point(258, 93);
            this.lblAPaterno.Name = "lblAPaterno";
            this.lblAPaterno.Size = new System.Drawing.Size(60, 20);
            this.lblAPaterno.TabIndex = 4;
            this.lblAPaterno.Text = "Santos";
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(114, 116);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(112, 13);
            this.bunifuSeparator2.TabIndex = 6;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNombre.Location = new System.Drawing.Point(110, 93);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(45, 20);
            this.lblNombre.TabIndex = 7;
            this.lblNombre.Text = "Karla";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(576, 40);
            this.panel2.TabIndex = 10;
            // 
            // pnMonto
            // 
            this.pnMonto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.pnMonto.Controls.Add(this.txtImporte);
            this.pnMonto.Controls.Add(this.bunifuSeparator5);
            this.pnMonto.Controls.Add(this.panel3);
            this.pnMonto.Controls.Add(this.txtMtoEscrito);
            this.pnMonto.Controls.Add(this.label8);
            this.pnMonto.Controls.Add(this.label7);
            this.pnMonto.Location = new System.Drawing.Point(28, 297);
            this.pnMonto.Name = "pnMonto";
            this.pnMonto.Size = new System.Drawing.Size(576, 122);
            this.pnMonto.TabIndex = 25;
            // 
            // txtImporte
            // 
            this.txtImporte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtImporte.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtImporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtImporte.Location = new System.Drawing.Point(66, 77);
            this.txtImporte.Name = "txtImporte";
            this.txtImporte.Size = new System.Drawing.Size(84, 19);
            this.txtImporte.TabIndex = 3;
            this.txtImporte.Text = "12";
            this.txtImporte.TextChanged += new System.EventHandler(this.txtImporte_TextChanged);
            this.txtImporte.Validating += new System.ComponentModel.CancelEventHandler(this.txtImporte_Validating);
            this.txtImporte.Validated += new System.EventHandler(this.txtImporte_Validated);
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(67, 92);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(83, 13);
            this.bunifuSeparator5.TabIndex = 1;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.label11);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(576, 40);
            this.panel3.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(11, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Monto";
            // 
            // txtMtoEscrito
            // 
            this.txtMtoEscrito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtMtoEscrito.BorderColorFocused = System.Drawing.Color.Blue;
            this.txtMtoEscrito.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.txtMtoEscrito.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.txtMtoEscrito.BorderThickness = 1;
            this.txtMtoEscrito.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMtoEscrito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtMtoEscrito.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtMtoEscrito.isPassword = false;
            this.txtMtoEscrito.Location = new System.Drawing.Point(249, 68);
            this.txtMtoEscrito.Margin = new System.Windows.Forms.Padding(4);
            this.txtMtoEscrito.Name = "txtMtoEscrito";
            this.txtMtoEscrito.Size = new System.Drawing.Size(276, 30);
            this.txtMtoEscrito.TabIndex = 4;
            this.txtMtoEscrito.Text = "Tres Mil";
            this.txtMtoEscrito.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.panel9.Controls.Add(this.cmdGuardar);
            this.panel9.Controls.Add(this.pictureBox2);
            this.panel9.Controls.Add(this.lblTitle);
            this.panel9.Controls.Add(this.btnAgregarRecibo);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel9.Location = new System.Drawing.Point(643, 43);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(153, 557);
            this.panel9.TabIndex = 0;
            // 
            // cmdGuardar
            // 
            this.cmdGuardar.ActiveBorderThickness = 1;
            this.cmdGuardar.ActiveCornerRadius = 20;
            this.cmdGuardar.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.cmdGuardar.ActiveForecolor = System.Drawing.Color.White;
            this.cmdGuardar.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.cmdGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.cmdGuardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cmdGuardar.BackgroundImage")));
            this.cmdGuardar.ButtonText = "Guardar";
            this.cmdGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdGuardar.ForeColor = System.Drawing.Color.SeaGreen;
            this.cmdGuardar.IdleBorderThickness = 1;
            this.cmdGuardar.IdleCornerRadius = 20;
            this.cmdGuardar.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.cmdGuardar.IdleForecolor = System.Drawing.Color.White;
            this.cmdGuardar.IdleLineColor = System.Drawing.Color.White;
            this.cmdGuardar.Location = new System.Drawing.Point(27, 458);
            this.cmdGuardar.Margin = new System.Windows.Forms.Padding(5);
            this.cmdGuardar.Name = "cmdGuardar";
            this.cmdGuardar.Size = new System.Drawing.Size(111, 50);
            this.cmdGuardar.TabIndex = 0;
            this.cmdGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdGuardar.Click += new System.EventHandler(this.cmdGuardar_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-9, 249);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(172, 185);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // btnAgregarRecibo
            // 
            this.btnAgregarRecibo.ActiveBorderThickness = 1;
            this.btnAgregarRecibo.ActiveCornerRadius = 20;
            this.btnAgregarRecibo.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarRecibo.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.btnAgregarRecibo.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarRecibo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.btnAgregarRecibo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgregarRecibo.BackgroundImage")));
            this.btnAgregarRecibo.ButtonText = "Agregar";
            this.btnAgregarRecibo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarRecibo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarRecibo.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAgregarRecibo.IdleBorderThickness = 1;
            this.btnAgregarRecibo.IdleCornerRadius = 20;
            this.btnAgregarRecibo.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarRecibo.IdleForecolor = System.Drawing.Color.White;
            this.btnAgregarRecibo.IdleLineColor = System.Drawing.Color.White;
            this.btnAgregarRecibo.Location = new System.Drawing.Point(27, 458);
            this.btnAgregarRecibo.Margin = new System.Windows.Forms.Padding(5);
            this.btnAgregarRecibo.Name = "btnAgregarRecibo";
            this.btnAgregarRecibo.Size = new System.Drawing.Size(111, 50);
            this.btnAgregarRecibo.TabIndex = 2;
            this.btnAgregarRecibo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAgregarRecibo.Click += new System.EventHandler(this.btnAgregarRecibo_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(39, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Folio:";
            // 
            // dtFecha
            // 
            this.dtFecha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.dtFecha.BorderRadius = 0;
            this.dtFecha.ForeColor = System.Drawing.Color.White;
            this.dtFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFecha.FormatCustom = null;
            this.dtFecha.Location = new System.Drawing.Point(409, 88);
            this.dtFecha.Name = "dtFecha";
            this.dtFecha.Size = new System.Drawing.Size(194, 23);
            this.dtFecha.TabIndex = 2;
            this.dtFecha.Value = new System.DateTime(2023, 4, 30, 0, 0, 0, 0);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(28, 425);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(576, 27);
            this.bunifuSeparator1.TabIndex = 3;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // pnFirmas
            // 
            this.pnFirmas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(218)))), ((int)(((byte)(203)))));
            this.pnFirmas.Controls.Add(this.pnEstatus);
            this.pnFirmas.Controls.Add(this.lblEncargado2);
            this.pnFirmas.Controls.Add(this.txtEncargado1);
            this.pnFirmas.Controls.Add(this.cbEncargado2);
            this.pnFirmas.Controls.Add(this.panel5);
            this.pnFirmas.Controls.Add(this.label12);
            this.pnFirmas.Controls.Add(this.label13);
            this.pnFirmas.Location = new System.Drawing.Point(28, 458);
            this.pnFirmas.Name = "pnFirmas";
            this.pnFirmas.Size = new System.Drawing.Size(576, 122);
            this.pnFirmas.TabIndex = 38;
            // 
            // pnEstatus
            // 
            this.pnEstatus.Controls.Add(this.cmdAgregarEstatus);
            this.pnEstatus.Controls.Add(this.lblEstatus);
            this.pnEstatus.Controls.Add(this.cbEstatus);
            this.pnEstatus.Location = new System.Drawing.Point(426, 58);
            this.pnEstatus.Name = "pnEstatus";
            this.pnEstatus.Size = new System.Drawing.Size(134, 63);
            this.pnEstatus.TabIndex = 1;
            // 
            // cmdAgregarEstatus
            // 
            this.cmdAgregarEstatus.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.agregar__1_;
            this.cmdAgregarEstatus.Location = new System.Drawing.Point(80, 5);
            this.cmdAgregarEstatus.Name = "cmdAgregarEstatus";
            this.cmdAgregarEstatus.Size = new System.Drawing.Size(41, 20);
            this.cmdAgregarEstatus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cmdAgregarEstatus.TabIndex = 45;
            this.cmdAgregarEstatus.TabStop = false;
            this.cmdAgregarEstatus.Click += new System.EventHandler(this.cmdAgregarEstatus_Click);
            // 
            // lblEstatus
            // 
            this.lblEstatus.AutoSize = true;
            this.lblEstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstatus.Location = new System.Drawing.Point(6, 5);
            this.lblEstatus.Name = "lblEstatus";
            this.lblEstatus.Size = new System.Drawing.Size(64, 20);
            this.lblEstatus.TabIndex = 0;
            this.lblEstatus.Text = "Estatus";
            // 
            // cbEstatus
            // 
            this.cbEstatus.FormattingEnabled = true;
            this.cbEstatus.Location = new System.Drawing.Point(10, 28);
            this.cbEstatus.Name = "cbEstatus";
            this.cbEstatus.Size = new System.Drawing.Size(111, 21);
            this.cbEstatus.TabIndex = 6;
            // 
            // lblEncargado2
            // 
            this.lblEncargado2.AutoSize = true;
            this.lblEncargado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEncargado2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblEncargado2.Location = new System.Drawing.Point(122, 86);
            this.lblEncargado2.Name = "lblEncargado2";
            this.lblEncargado2.Size = new System.Drawing.Size(196, 20);
            this.lblEncargado2.TabIndex = 3;
            this.lblEncargado2.Text = "Karla Judith Santos Rivera";
            // 
            // txtEncargado1
            // 
            this.txtEncargado1.AutoSize = true;
            this.txtEncargado1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEncargado1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEncargado1.Location = new System.Drawing.Point(121, 52);
            this.txtEncargado1.Name = "txtEncargado1";
            this.txtEncargado1.Size = new System.Drawing.Size(196, 20);
            this.txtEncargado1.TabIndex = 2;
            this.txtEncargado1.Text = "Karla Judith Santos Rivera";
            // 
            // cbEncargado2
            // 
            this.cbEncargado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEncargado2.FormattingEnabled = true;
            this.cbEncargado2.Location = new System.Drawing.Point(121, 81);
            this.cbEncargado2.Name = "cbEncargado2";
            this.cbEncargado2.Size = new System.Drawing.Size(255, 26);
            this.cbEncargado2.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.label9);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(576, 40);
            this.panel5.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(11, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Firmas";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(11, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 20);
            this.label12.TabIndex = 4;
            this.label12.Text = "Encargado 2:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(11, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 20);
            this.label13.TabIndex = 5;
            this.label13.Text = "Encargado 1:";
            // 
            // rdSocio
            // 
            this.rdSocio.ElipseRadius = 20;
            this.rdSocio.TargetControl = this.pnSocio;
            // 
            // rdMonto
            // 
            this.rdMonto.ElipseRadius = 20;
            this.rdMonto.TargetControl = this.pnMonto;
            // 
            // rdFirmas
            // 
            this.rdFirmas.ElipseRadius = 20;
            this.rdFirmas.TargetControl = this.pnFirmas;
            // 
            // cbPeriodo
            // 
            this.cbPeriodo.FormattingEnabled = true;
            this.cbPeriodo.Location = new System.Drawing.Point(210, 88);
            this.cbPeriodo.Name = "cbPeriodo";
            this.cbPeriodo.Size = new System.Drawing.Size(125, 21);
            this.cbPeriodo.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(206, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 20);
            this.label14.TabIndex = 6;
            this.label14.Text = "Periodo:";
            // 
            // lblPeriodo
            // 
            this.lblPeriodo.AutoSize = true;
            this.lblPeriodo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeriodo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPeriodo.Location = new System.Drawing.Point(214, 86);
            this.lblPeriodo.Name = "lblPeriodo";
            this.lblPeriodo.Size = new System.Drawing.Size(68, 20);
            this.lblPeriodo.TabIndex = 7;
            this.lblPeriodo.Text = "20181-1";
            // 
            // error1
            // 
            this.error1.ContainerControl = this;
            this.error1.Icon = ((System.Drawing.Icon)(resources.GetObject("error1.Icon")));
            // 
            // txtFolio
            // 
            this.txtFolio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtFolio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFolio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtFolio.Location = new System.Drawing.Point(43, 82);
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.Size = new System.Drawing.Size(84, 19);
            this.txtFolio.TabIndex = 0;
            this.txtFolio.Text = "12";
            this.txtFolio.Validating += new System.ComponentModel.CancelEventHandler(this.txtFolio_Validating);
            this.txtFolio.Validated += new System.EventHandler(this.txtFolio_Validated);
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(44, 97);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(83, 13);
            this.bunifuSeparator6.TabIndex = 8;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // frmNuevaAportacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.ClientSize = new System.Drawing.Size(796, 600);
            this.Controls.Add(this.txtFolio);
            this.Controls.Add(this.bunifuSeparator6);
            this.Controls.Add(this.lblPeriodo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cbPeriodo);
            this.Controls.Add(this.pnFirmas);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.dtFecha);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnSocio);
            this.Controls.Add(this.pnMonto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNuevaAportacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmNuevaAportacion";
            this.Load += new System.EventHandler(this.frmNuevaAportacion_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.pnSocio.ResumeLayout(false);
            this.pnSocio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnMonto.ResumeLayout(false);
            this.pnMonto.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnFirmas.ResumeLayout(false);
            this.pnFirmas.PerformLayout();
            this.pnEstatus.ResumeLayout(false);
            this.pnEstatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmdAgregarEstatus)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public ns1.BunifuElipse rdNuevaAportacion;
        public System.Windows.Forms.Panel panel1;
        public ns1.BunifuImageButton bunifuImageButton1;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label lblTitle;
        public ns1.BunifuThinButton2 btnAgregarRecibo;
        public System.Windows.Forms.Panel pnSocio;
        public System.Windows.Forms.Panel pnMonto;
        public System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.Label label10;
        public ns1.BunifuMetroTextbox txtMtoEscrito;
        public ns1.BunifuDatepicker dtFecha;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Label label11;
        public ns1.BunifuSeparator bunifuSeparator1;
        public ns1.BunifuImageButton btnCerrar;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBox3;
        public ns1.BunifuThinButton2 cmdBuscar;
        public ns1.BunifuSeparator bunifuSeparator4;
        public ns1.BunifuCustomLabel lblAMaterno;
        public ns1.BunifuSeparator bunifuSeparator3;
        public ns1.BunifuCustomLabel lblAPaterno;
        public ns1.BunifuSeparator bunifuSeparator2;
        public ns1.BunifuCustomLabel lblNombre;
        public System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.PictureBox pictureBox5;
        public System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.Panel pnFirmas;
        public System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label13;
        public ns1.BunifuCustomLabel txtEncargado1;
        public System.Windows.Forms.ComboBox cbEncargado2;
        public ns1.BunifuElipse rdSocio;
        public ns1.BunifuElipse rdMonto;
        public ns1.BunifuElipse rdFirmas;
        public ns1.BunifuThinButton2 cmdGuardar;
        public System.Windows.Forms.Label lblEstatus;
        public System.Windows.Forms.ComboBox cbEstatus;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.ComboBox cbPeriodo;
        public ns1.BunifuCustomLabel lblEncargado2;
        public System.Windows.Forms.PictureBox cmdAgregarEstatus;
        public System.Windows.Forms.Panel pnEstatus;
        public ns1.BunifuCustomLabel lblPeriodo;
        private System.Windows.Forms.ErrorProvider error1;
        public System.Windows.Forms.TextBox txtImporte;
        public ns1.BunifuSeparator bunifuSeparator5;
        public System.Windows.Forms.TextBox txtFolio;
        public ns1.BunifuSeparator bunifuSeparator6;
        private System.Drawing.Printing.PrintDocument imprimirRec;
    }
}