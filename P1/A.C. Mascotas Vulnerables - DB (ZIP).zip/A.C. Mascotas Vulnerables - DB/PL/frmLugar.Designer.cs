﻿namespace A.C.Mascotas_Vulnerables___DB.PL
{
    partial class frmLugar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLugar));
            this.rdLugar = new ns1.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuImageButton1 = new ns1.BunifuImageButton();
            this.label28 = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.cbPais = new System.Windows.Forms.ComboBox();
            this.lblPais = new System.Windows.Forms.Label();
            this.txtPaisID = new System.Windows.Forms.TextBox();
            this.lblPaisID = new System.Windows.Forms.Label();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.txtNombrePais = new System.Windows.Forms.TextBox();
            this.lblNombrePais = new System.Windows.Forms.Label();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.txtEstadoID = new System.Windows.Forms.TextBox();
            this.lblEstadoID = new System.Windows.Forms.Label();
            this.bunifuSeparator6 = new ns1.BunifuSeparator();
            this.txtNombreEstado = new System.Windows.Forms.TextBox();
            this.lblNombreEstado = new System.Windows.Forms.Label();
            this.bunifuSeparator7 = new ns1.BunifuSeparator();
            this.txtCiudadID = new System.Windows.Forms.TextBox();
            this.lblCiudadID = new System.Windows.Forms.Label();
            this.bunifuSeparator8 = new ns1.BunifuSeparator();
            this.txtNombreCiudad = new System.Windows.Forms.TextBox();
            this.lblNombreCiudad = new System.Windows.Forms.Label();
            this.bunifuSeparator9 = new ns1.BunifuSeparator();
            this.cbEstado = new System.Windows.Forms.ComboBox();
            this.lblEstado = new System.Windows.Forms.Label();
            this.dgvPais = new System.Windows.Forms.DataGridView();
            this.dgvEstado = new System.Windows.Forms.DataGridView();
            this.dgvCiudad = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnAgregarCiudad = new ns1.BunifuThinButton2();
            this.btnAgregarEstado = new ns1.BunifuThinButton2();
            this.btnAgregarPais = new ns1.BunifuThinButton2();
            this.label3 = new System.Windows.Forms.Label();
            this.cmdModificarPais = new ns1.BunifuThinButton2();
            this.cmdModificarEstado = new ns1.BunifuThinButton2();
            this.cmdModificarCiudad = new ns1.BunifuThinButton2();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.error1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPais)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCiudad)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).BeginInit();
            this.SuspendLayout();
            // 
            // rdLugar
            // 
            this.rdLugar.ElipseRadius = 35;
            this.rdLugar.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(685, 43);
            this.panel1.TabIndex = 25;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Gadugi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(225, 7);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(295, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "AGREGAR NUEVA UBICACION";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.perro;
            this.pictureBox1.Location = new System.Drawing.Point(13, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = global::A.C.Mascotas_Vulnerables___DB.Properties.Resources.Equis;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(631, 5);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(33, 35);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 0;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.IndianRed;
            this.label28.Location = new System.Drawing.Point(313, 54);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(46, 20);
            this.label28.TabIndex = 28;
            this.label28.Text = "PAIS";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator1.LineThickness = 4;
            this.bunifuSeparator1.Location = new System.Drawing.Point(21, 54);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(630, 20);
            this.bunifuSeparator1.TabIndex = 27;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(296, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "ESTADO";
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator2.LineThickness = 4;
            this.bunifuSeparator2.Location = new System.Drawing.Point(21, 3);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(630, 17);
            this.bunifuSeparator2.TabIndex = 32;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(285, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.TabIndex = 36;
            this.label2.Text = "CIUDAD";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            this.bunifuSeparator3.LineThickness = 4;
            this.bunifuSeparator3.Location = new System.Drawing.Point(19, 7);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(630, 20);
            this.bunifuSeparator3.TabIndex = 35;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // cbPais
            // 
            this.cbPais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cbPais.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbPais.FormattingEnabled = true;
            this.cbPais.Items.AddRange(new object[] {
            "FISICA",
            "MORAL"});
            this.cbPais.Location = new System.Drawing.Point(450, 158);
            this.cbPais.Name = "cbPais";
            this.cbPais.Size = new System.Drawing.Size(172, 26);
            this.cbPais.TabIndex = 12;
            this.cbPais.Text = "- Seleccione -";
            this.cbPais.SelectedIndexChanged += new System.EventHandler(this.cbPais_SelectedIndexChanged);
            // 
            // lblPais
            // 
            this.lblPais.AutoSize = true;
            this.lblPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPais.Location = new System.Drawing.Point(447, 137);
            this.lblPais.Name = "lblPais";
            this.lblPais.Size = new System.Drawing.Size(37, 18);
            this.lblPais.TabIndex = 11;
            this.lblPais.Text = "País";
            // 
            // txtPaisID
            // 
            this.txtPaisID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtPaisID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPaisID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPaisID.Location = new System.Drawing.Point(36, 103);
            this.txtPaisID.Name = "txtPaisID";
            this.txtPaisID.Size = new System.Drawing.Size(84, 19);
            this.txtPaisID.TabIndex = 1;
            this.txtPaisID.Text = "1";
            this.txtPaisID.TextChanged += new System.EventHandler(this.txtPaisID_TextChanged);
            this.txtPaisID.Validating += new System.ComponentModel.CancelEventHandler(this.txtPaisID_Validating);
            this.txtPaisID.Validated += new System.EventHandler(this.txtPaisID_Validated);
            // 
            // lblPaisID
            // 
            this.lblPaisID.AutoSize = true;
            this.lblPaisID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaisID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPaisID.Location = new System.Drawing.Point(33, 80);
            this.lblPaisID.Name = "lblPaisID";
            this.lblPaisID.Size = new System.Drawing.Size(82, 18);
            this.lblPaisID.TabIndex = 0;
            this.lblPaisID.Text = "ID del País:";
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(37, 113);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(83, 18);
            this.bunifuSeparator5.TabIndex = 29;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // txtNombrePais
            // 
            this.txtNombrePais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNombrePais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombrePais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombrePais.Location = new System.Drawing.Point(36, 157);
            this.txtNombrePais.Name = "txtNombrePais";
            this.txtNombrePais.Size = new System.Drawing.Size(172, 19);
            this.txtNombrePais.TabIndex = 3;
            this.txtNombrePais.Text = "MÉXICO";
            this.txtNombrePais.TextChanged += new System.EventHandler(this.txtNombrePais_TextChanged);
            this.txtNombrePais.Validating += new System.ComponentModel.CancelEventHandler(this.txtNombrePais_Validating);
            this.txtNombrePais.Validated += new System.EventHandler(this.txtNombrePais_Validated);
            // 
            // lblNombrePais
            // 
            this.lblNombrePais.AutoSize = true;
            this.lblNombrePais.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombrePais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNombrePais.Location = new System.Drawing.Point(33, 134);
            this.lblNombrePais.Name = "lblNombrePais";
            this.lblNombrePais.Size = new System.Drawing.Size(66, 18);
            this.lblNombrePais.TabIndex = 2;
            this.lblNombrePais.Text = "Nombre:";
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(37, 167);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(171, 18);
            this.bunifuSeparator4.TabIndex = 30;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // txtEstadoID
            // 
            this.txtEstadoID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtEstadoID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEstadoID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEstadoID.Location = new System.Drawing.Point(449, 47);
            this.txtEstadoID.Name = "txtEstadoID";
            this.txtEstadoID.Size = new System.Drawing.Size(84, 19);
            this.txtEstadoID.TabIndex = 8;
            this.txtEstadoID.Text = "12";
            this.txtEstadoID.TextChanged += new System.EventHandler(this.txtEstadoID_TextChanged);
            this.txtEstadoID.Validating += new System.ComponentModel.CancelEventHandler(this.txtEstadoID_Validating);
            this.txtEstadoID.Validated += new System.EventHandler(this.txtEstadoID_Validated);
            // 
            // lblEstadoID
            // 
            this.lblEstadoID.AutoSize = true;
            this.lblEstadoID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstadoID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblEstadoID.Location = new System.Drawing.Point(446, 24);
            this.lblEstadoID.Name = "lblEstadoID";
            this.lblEstadoID.Size = new System.Drawing.Size(100, 18);
            this.lblEstadoID.TabIndex = 7;
            this.lblEstadoID.Text = "ID del Estado:";
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(450, 65);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(83, 10);
            this.bunifuSeparator6.TabIndex = 33;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // txtNombreEstado
            // 
            this.txtNombreEstado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNombreEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombreEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombreEstado.Location = new System.Drawing.Point(450, 104);
            this.txtNombreEstado.Name = "txtNombreEstado";
            this.txtNombreEstado.Size = new System.Drawing.Size(172, 19);
            this.txtNombreEstado.TabIndex = 10;
            this.txtNombreEstado.Text = "BAJA CALIFORNIA";
            this.txtNombreEstado.TextChanged += new System.EventHandler(this.txtNombreEstado_TextChanged);
            this.txtNombreEstado.Validating += new System.ComponentModel.CancelEventHandler(this.txtNombreEstado_Validating);
            this.txtNombreEstado.Validated += new System.EventHandler(this.txtNombreEstado_Validated);
            // 
            // lblNombreEstado
            // 
            this.lblNombreEstado.AutoSize = true;
            this.lblNombreEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNombreEstado.Location = new System.Drawing.Point(447, 80);
            this.lblNombreEstado.Name = "lblNombreEstado";
            this.lblNombreEstado.Size = new System.Drawing.Size(66, 18);
            this.lblNombreEstado.TabIndex = 9;
            this.lblNombreEstado.Text = "Nombre:";
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator7.LineThickness = 1;
            this.bunifuSeparator7.Location = new System.Drawing.Point(451, 122);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(171, 10);
            this.bunifuSeparator7.TabIndex = 34;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // txtCiudadID
            // 
            this.txtCiudadID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtCiudadID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCiudadID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCiudadID.Location = new System.Drawing.Point(37, 52);
            this.txtCiudadID.Name = "txtCiudadID";
            this.txtCiudadID.Size = new System.Drawing.Size(84, 19);
            this.txtCiudadID.TabIndex = 17;
            this.txtCiudadID.Text = "3";
            this.txtCiudadID.TextChanged += new System.EventHandler(this.txtCiudadID_TextChanged);
            this.txtCiudadID.Validating += new System.ComponentModel.CancelEventHandler(this.txtCiudadID_Validating);
            this.txtCiudadID.Validated += new System.EventHandler(this.txtCiudadID_Validated);
            // 
            // lblCiudadID
            // 
            this.lblCiudadID.AutoSize = true;
            this.lblCiudadID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCiudadID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCiudadID.Location = new System.Drawing.Point(34, 29);
            this.lblCiudadID.Name = "lblCiudadID";
            this.lblCiudadID.Size = new System.Drawing.Size(96, 18);
            this.lblCiudadID.TabIndex = 16;
            this.lblCiudadID.Text = "ID de Ciudad:";
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(38, 70);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(83, 10);
            this.bunifuSeparator8.TabIndex = 37;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = false;
            // 
            // txtNombreCiudad
            // 
            this.txtNombreCiudad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.txtNombreCiudad.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombreCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombreCiudad.Location = new System.Drawing.Point(37, 106);
            this.txtNombreCiudad.Name = "txtNombreCiudad";
            this.txtNombreCiudad.Size = new System.Drawing.Size(172, 19);
            this.txtNombreCiudad.TabIndex = 19;
            this.txtNombreCiudad.Text = "TIJUANA";
            this.txtNombreCiudad.TextChanged += new System.EventHandler(this.txtNombreCiudad_TextChanged);
            this.txtNombreCiudad.Validating += new System.ComponentModel.CancelEventHandler(this.txtNombreCiudad_Validating);
            this.txtNombreCiudad.Validated += new System.EventHandler(this.txtNombreCiudad_Validated);
            // 
            // lblNombreCiudad
            // 
            this.lblNombreCiudad.AutoSize = true;
            this.lblNombreCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCiudad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblNombreCiudad.Location = new System.Drawing.Point(34, 83);
            this.lblNombreCiudad.Name = "lblNombreCiudad";
            this.lblNombreCiudad.Size = new System.Drawing.Size(66, 18);
            this.lblNombreCiudad.TabIndex = 18;
            this.lblNombreCiudad.Text = "Nombre:";
            // 
            // bunifuSeparator9
            // 
            this.bunifuSeparator9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.bunifuSeparator9.LineThickness = 1;
            this.bunifuSeparator9.Location = new System.Drawing.Point(38, 124);
            this.bunifuSeparator9.Name = "bunifuSeparator9";
            this.bunifuSeparator9.Size = new System.Drawing.Size(171, 10);
            this.bunifuSeparator9.TabIndex = 38;
            this.bunifuSeparator9.Transparency = 255;
            this.bunifuSeparator9.Vertical = false;
            // 
            // cbEstado
            // 
            this.cbEstado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cbEstado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cbEstado.FormattingEnabled = true;
            this.cbEstado.Items.AddRange(new object[] {
            "FISICA",
            "MORAL"});
            this.cbEstado.Location = new System.Drawing.Point(37, 158);
            this.cbEstado.Name = "cbEstado";
            this.cbEstado.Size = new System.Drawing.Size(172, 26);
            this.cbEstado.TabIndex = 21;
            this.cbEstado.Text = "- Seleccione -";
            this.cbEstado.SelectedIndexChanged += new System.EventHandler(this.cbEstado_SelectedIndexChanged);
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblEstado.Location = new System.Drawing.Point(34, 137);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(55, 18);
            this.lblEstado.TabIndex = 20;
            this.lblEstado.Text = "Estado";
            // 
            // dgvPais
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvPais.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvPais.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPais.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.dgvPais.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvPais.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPais.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvPais.ColumnHeadersHeight = 30;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(237)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPais.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvPais.EnableHeadersVisualStyles = false;
            this.dgvPais.GridColor = System.Drawing.Color.Black;
            this.dgvPais.Location = new System.Drawing.Point(296, 85);
            this.dgvPais.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.dgvPais.Name = "dgvPais";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(88)))), ((int)(((byte)(113)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPais.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvPais.RowHeadersVisible = false;
            this.dgvPais.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvPais.RowTemplate.Height = 30;
            this.dgvPais.Size = new System.Drawing.Size(327, 136);
            this.dgvPais.TabIndex = 4;
            this.dgvPais.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.ModificarPais);
            // 
            // dgvEstado
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvEstado.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvEstado.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEstado.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.dgvEstado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvEstado.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(180)))), ((int)(((byte)(82)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(206)))), ((int)(((byte)(145)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEstado.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvEstado.ColumnHeadersHeight = 30;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(237)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEstado.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvEstado.EnableHeadersVisualStyles = false;
            this.dgvEstado.GridColor = System.Drawing.Color.Black;
            this.dgvEstado.Location = new System.Drawing.Point(33, 31);
            this.dgvEstado.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.dgvEstado.Name = "dgvEstado";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(88)))), ((int)(((byte)(113)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEstado.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvEstado.RowHeadersVisible = false;
            this.dgvEstado.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvEstado.RowTemplate.Height = 30;
            this.dgvEstado.Size = new System.Drawing.Size(382, 200);
            this.dgvEstado.TabIndex = 15;
            this.dgvEstado.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.ModificarEstado);
            // 
            // dgvCiudad
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(193)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvCiudad.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCiudad.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCiudad.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.dgvCiudad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCiudad.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(151)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCiudad.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCiudad.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(237)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCiudad.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvCiudad.EnableHeadersVisualStyles = false;
            this.dgvCiudad.GridColor = System.Drawing.Color.Black;
            this.dgvCiudad.Location = new System.Drawing.Point(253, 29);
            this.dgvCiudad.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.dgvCiudad.Name = "dgvCiudad";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(88)))), ((int)(((byte)(113)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCiudad.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCiudad.RowHeadersVisible = false;
            this.dgvCiudad.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvCiudad.RowTemplate.Height = 30;
            this.dgvCiudad.Size = new System.Drawing.Size(376, 191);
            this.dgvCiudad.TabIndex = 24;
            this.dgvCiudad.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.ModificarCiudad);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 787);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(685, 10);
            this.panel2.TabIndex = 40;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(324, 768);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(208, 19);
            this.panel3.TabIndex = 39;
            // 
            // btnAgregarCiudad
            // 
            this.btnAgregarCiudad.ActiveBorderThickness = 1;
            this.btnAgregarCiudad.ActiveCornerRadius = 20;
            this.btnAgregarCiudad.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarCiudad.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.btnAgregarCiudad.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarCiudad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.btnAgregarCiudad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgregarCiudad.BackgroundImage")));
            this.btnAgregarCiudad.ButtonText = "Agregar";
            this.btnAgregarCiudad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarCiudad.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAgregarCiudad.IdleBorderThickness = 1;
            this.btnAgregarCiudad.IdleCornerRadius = 20;
            this.btnAgregarCiudad.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.btnAgregarCiudad.IdleForecolor = System.Drawing.Color.White;
            this.btnAgregarCiudad.IdleLineColor = System.Drawing.Color.Black;
            this.btnAgregarCiudad.Location = new System.Drawing.Point(47, 192);
            this.btnAgregarCiudad.Margin = new System.Windows.Forms.Padding(5);
            this.btnAgregarCiudad.Name = "btnAgregarCiudad";
            this.btnAgregarCiudad.Size = new System.Drawing.Size(90, 37);
            this.btnAgregarCiudad.TabIndex = 22;
            this.btnAgregarCiudad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAgregarCiudad.Click += new System.EventHandler(this.btnAgregarCiudad_Click);
            // 
            // btnAgregarEstado
            // 
            this.btnAgregarEstado.ActiveBorderThickness = 1;
            this.btnAgregarEstado.ActiveCornerRadius = 20;
            this.btnAgregarEstado.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarEstado.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.btnAgregarEstado.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarEstado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.btnAgregarEstado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgregarEstado.BackgroundImage")));
            this.btnAgregarEstado.ButtonText = "Agregar";
            this.btnAgregarEstado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarEstado.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAgregarEstado.IdleBorderThickness = 1;
            this.btnAgregarEstado.IdleCornerRadius = 20;
            this.btnAgregarEstado.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.btnAgregarEstado.IdleForecolor = System.Drawing.Color.White;
            this.btnAgregarEstado.IdleLineColor = System.Drawing.Color.Black;
            this.btnAgregarEstado.Location = new System.Drawing.Point(432, 195);
            this.btnAgregarEstado.Margin = new System.Windows.Forms.Padding(5);
            this.btnAgregarEstado.Name = "btnAgregarEstado";
            this.btnAgregarEstado.Size = new System.Drawing.Size(97, 37);
            this.btnAgregarEstado.TabIndex = 13;
            this.btnAgregarEstado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAgregarEstado.Click += new System.EventHandler(this.btnAgregarEstado_Click);
            // 
            // btnAgregarPais
            // 
            this.btnAgregarPais.ActiveBorderThickness = 1;
            this.btnAgregarPais.ActiveCornerRadius = 20;
            this.btnAgregarPais.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarPais.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.btnAgregarPais.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.btnAgregarPais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.btnAgregarPais.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgregarPais.BackgroundImage")));
            this.btnAgregarPais.ButtonText = "Agregar";
            this.btnAgregarPais.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarPais.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAgregarPais.IdleBorderThickness = 1;
            this.btnAgregarPais.IdleCornerRadius = 20;
            this.btnAgregarPais.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.btnAgregarPais.IdleForecolor = System.Drawing.Color.White;
            this.btnAgregarPais.IdleLineColor = System.Drawing.Color.Black;
            this.btnAgregarPais.Location = new System.Drawing.Point(33, 184);
            this.btnAgregarPais.Margin = new System.Windows.Forms.Padding(5);
            this.btnAgregarPais.Name = "btnAgregarPais";
            this.btnAgregarPais.Size = new System.Drawing.Size(105, 37);
            this.btnAgregarPais.TabIndex = 5;
            this.btnAgregarPais.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAgregarPais.Click += new System.EventHandler(this.btnAgregarPais_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(7)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(45, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(579, 40);
            this.label3.TabIndex = 26;
            this.label3.Text = "Nota: De doble click sobre cualquier registro para recuperar la informacio y pode" +
    "r \r\nmodificarla.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmdModificarPais
            // 
            this.cmdModificarPais.ActiveBorderThickness = 1;
            this.cmdModificarPais.ActiveCornerRadius = 20;
            this.cmdModificarPais.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarPais.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.cmdModificarPais.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarPais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cmdModificarPais.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cmdModificarPais.BackgroundImage")));
            this.cmdModificarPais.ButtonText = "Modificar";
            this.cmdModificarPais.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdModificarPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdModificarPais.ForeColor = System.Drawing.Color.SeaGreen;
            this.cmdModificarPais.IdleBorderThickness = 1;
            this.cmdModificarPais.IdleCornerRadius = 20;
            this.cmdModificarPais.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.cmdModificarPais.IdleForecolor = System.Drawing.Color.White;
            this.cmdModificarPais.IdleLineColor = System.Drawing.Color.Black;
            this.cmdModificarPais.Location = new System.Drawing.Point(148, 184);
            this.cmdModificarPais.Margin = new System.Windows.Forms.Padding(5);
            this.cmdModificarPais.Name = "cmdModificarPais";
            this.cmdModificarPais.Size = new System.Drawing.Size(101, 37);
            this.cmdModificarPais.TabIndex = 6;
            this.cmdModificarPais.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdModificarPais.Click += new System.EventHandler(this.cmdModificarPais_Click);
            // 
            // cmdModificarEstado
            // 
            this.cmdModificarEstado.ActiveBorderThickness = 1;
            this.cmdModificarEstado.ActiveCornerRadius = 20;
            this.cmdModificarEstado.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarEstado.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.cmdModificarEstado.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarEstado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cmdModificarEstado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cmdModificarEstado.BackgroundImage")));
            this.cmdModificarEstado.ButtonText = "Modificar";
            this.cmdModificarEstado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdModificarEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdModificarEstado.ForeColor = System.Drawing.Color.SeaGreen;
            this.cmdModificarEstado.IdleBorderThickness = 1;
            this.cmdModificarEstado.IdleCornerRadius = 20;
            this.cmdModificarEstado.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.cmdModificarEstado.IdleForecolor = System.Drawing.Color.White;
            this.cmdModificarEstado.IdleLineColor = System.Drawing.Color.Black;
            this.cmdModificarEstado.Location = new System.Drawing.Point(539, 195);
            this.cmdModificarEstado.Margin = new System.Windows.Forms.Padding(5);
            this.cmdModificarEstado.Name = "cmdModificarEstado";
            this.cmdModificarEstado.Size = new System.Drawing.Size(92, 37);
            this.cmdModificarEstado.TabIndex = 14;
            this.cmdModificarEstado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdModificarEstado.Click += new System.EventHandler(this.cmdModificarEstado_Click);
            // 
            // cmdModificarCiudad
            // 
            this.cmdModificarCiudad.ActiveBorderThickness = 1;
            this.cmdModificarCiudad.ActiveCornerRadius = 20;
            this.cmdModificarCiudad.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarCiudad.ActiveForecolor = System.Drawing.SystemColors.Window;
            this.cmdModificarCiudad.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(126)))), ((int)(((byte)(150)))));
            this.cmdModificarCiudad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.cmdModificarCiudad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cmdModificarCiudad.BackgroundImage")));
            this.cmdModificarCiudad.ButtonText = "Modificar";
            this.cmdModificarCiudad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmdModificarCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdModificarCiudad.ForeColor = System.Drawing.Color.SeaGreen;
            this.cmdModificarCiudad.IdleBorderThickness = 1;
            this.cmdModificarCiudad.IdleCornerRadius = 20;
            this.cmdModificarCiudad.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(120)))));
            this.cmdModificarCiudad.IdleForecolor = System.Drawing.Color.White;
            this.cmdModificarCiudad.IdleLineColor = System.Drawing.Color.Black;
            this.cmdModificarCiudad.Location = new System.Drawing.Point(150, 192);
            this.cmdModificarCiudad.Margin = new System.Windows.Forms.Padding(5);
            this.cmdModificarCiudad.Name = "cmdModificarCiudad";
            this.cmdModificarCiudad.Size = new System.Drawing.Size(92, 37);
            this.cmdModificarCiudad.TabIndex = 23;
            this.cmdModificarCiudad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdModificarCiudad.Click += new System.EventHandler(this.cmdModificarCiudad_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cmdModificarPais);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.btnAgregarPais);
            this.panel4.Controls.Add(this.dgvPais);
            this.panel4.Controls.Add(this.txtPaisID);
            this.panel4.Controls.Add(this.lblPaisID);
            this.panel4.Controls.Add(this.bunifuSeparator5);
            this.panel4.Controls.Add(this.txtNombrePais);
            this.panel4.Controls.Add(this.lblNombrePais);
            this.panel4.Controls.Add(this.bunifuSeparator4);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.bunifuSeparator1);
            this.panel4.Location = new System.Drawing.Point(1, 44);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(676, 240);
            this.panel4.TabIndex = 41;
            this.panel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cmdModificarEstado);
            this.panel5.Controls.Add(this.btnAgregarEstado);
            this.panel5.Controls.Add(this.dgvEstado);
            this.panel5.Controls.Add(this.txtEstadoID);
            this.panel5.Controls.Add(this.lblEstadoID);
            this.panel5.Controls.Add(this.bunifuSeparator6);
            this.panel5.Controls.Add(this.txtNombreEstado);
            this.panel5.Controls.Add(this.lblNombreEstado);
            this.panel5.Controls.Add(this.bunifuSeparator7);
            this.panel5.Controls.Add(this.cbPais);
            this.panel5.Controls.Add(this.lblPais);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.bunifuSeparator2);
            this.panel5.Location = new System.Drawing.Point(1, 284);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(676, 247);
            this.panel5.TabIndex = 42;
            this.panel5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.bunifuSeparator3);
            this.panel6.Controls.Add(this.cmdModificarCiudad);
            this.panel6.Controls.Add(this.btnAgregarCiudad);
            this.panel6.Controls.Add(this.dgvCiudad);
            this.panel6.Controls.Add(this.txtCiudadID);
            this.panel6.Controls.Add(this.lblCiudadID);
            this.panel6.Controls.Add(this.bunifuSeparator8);
            this.panel6.Controls.Add(this.txtNombreCiudad);
            this.panel6.Controls.Add(this.lblNombreCiudad);
            this.panel6.Controls.Add(this.bunifuSeparator9);
            this.panel6.Controls.Add(this.cbEstado);
            this.panel6.Controls.Add(this.lblEstado);
            this.panel6.Location = new System.Drawing.Point(3, 530);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(674, 238);
            this.panel6.TabIndex = 43;
            this.panel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Mover);
            // 
            // error1
            // 
            this.error1.ContainerControl = this;
            // 
            // frmLugar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(243)))), ((int)(((byte)(223)))));
            this.ClientSize = new System.Drawing.Size(702, 507);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmLugar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmLugar";
            this.Load += new System.EventHandler(this.frmLugar_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPais)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCiudad)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.error1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ns1.BunifuElipse rdLugar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ns1.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label2;
        private ns1.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.Label label1;
        private ns1.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.Label label28;
        private ns1.BunifuSeparator bunifuSeparator1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtCiudadID;
        private System.Windows.Forms.Label lblCiudadID;
        private ns1.BunifuSeparator bunifuSeparator8;
        private System.Windows.Forms.TextBox txtNombreCiudad;
        private System.Windows.Forms.Label lblNombreCiudad;
        private ns1.BunifuSeparator bunifuSeparator9;
        private System.Windows.Forms.ComboBox cbEstado;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.TextBox txtEstadoID;
        private System.Windows.Forms.Label lblEstadoID;
        private ns1.BunifuSeparator bunifuSeparator6;
        private System.Windows.Forms.TextBox txtNombreEstado;
        private System.Windows.Forms.Label lblNombreEstado;
        private ns1.BunifuSeparator bunifuSeparator7;
        private System.Windows.Forms.ComboBox cbPais;
        private System.Windows.Forms.Label lblPais;
        private System.Windows.Forms.TextBox txtPaisID;
        private System.Windows.Forms.Label lblPaisID;
        private ns1.BunifuSeparator bunifuSeparator5;
        private System.Windows.Forms.TextBox txtNombrePais;
        private System.Windows.Forms.Label lblNombrePais;
        private ns1.BunifuSeparator bunifuSeparator4;
        public System.Windows.Forms.DataGridView dgvPais;
        private ns1.BunifuThinButton2 btnAgregarPais;
        private ns1.BunifuThinButton2 btnAgregarCiudad;
        private ns1.BunifuThinButton2 btnAgregarEstado;
        public System.Windows.Forms.DataGridView dgvCiudad;
        public System.Windows.Forms.DataGridView dgvEstado;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private ns1.BunifuThinButton2 cmdModificarCiudad;
        private ns1.BunifuThinButton2 cmdModificarEstado;
        private ns1.BunifuThinButton2 cmdModificarPais;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ErrorProvider error1;
    }
}